/*
 * ***** BEGIN LICENSE BLOCK *****
 * Zimbra Collaboration Suite, Network Edition.
 * Copyright (C) 2012, 2013, 2014, 2016 Synacor, Inc.  All Rights Reserved.
 * ***** END LICENSE BLOCK *****
 *
 */

ZmVoiceAccountSettingsDlg = function() {
    this.zimlet = ZmVoicePrefs._INSTANCE;
    this.controller = ZmVoicePrefsGeneralController._INSTANCE;
    this._dialogView = new DwtComposite(appCtxt.getShell());
	this._createView();

    DwtDialog.call(this, {
        parent: appCtxt.getShell(),
		title: this.zimlet.getMessage("voiceAccountSettingsDlgTitle"),
        view: this._dialogView,
        standardButtons: [DwtDialog.OK_BUTTON, DwtDialog.CANCEL_BUTTON]
	});

	this.setButtonListener(DwtDialog.OK_BUTTON, new AjxListener(this, this._updateBtnHandler));

	var okButton = this.getButton(DwtDialog.OK_BUTTON);
	okButton.setText(this.zimlet.getMessage("updatePasswordDlgBtn"));

	this._passwordField = document.getElementById("voiceAccountSettingsDlg_PASSWORD_field");

	this._addTabControl();
};

ZmVoiceAccountSettingsDlg.prototype = new DwtDialog;
ZmVoiceAccountSettingsDlg.prototype.constructor = ZmVoiceAccountSettingsDlg;

ZmVoiceAccountSettingsDlg.PASSWORD_FIELD_ID = "voiceAccountSettingsDlg_PASSWORD_field";


ZmVoiceAccountSettingsDlg.prototype._createView = function() {
var subs = {
        usernameStr: this.zimlet.getMessage("usernameLabel"),
        passwordStr: this.zimlet.getMessage("passwordLabel"),
        username : ZmVoicePrefs._INSTANCE.username,
		passwordFieldId : ZmVoiceAccountSettingsDlg.PASSWORD_FIELD_ID
	};
	this._dialogView.getHtmlElement().innerHTML =  AjxTemplate.expand("voicemail.VoicePrefs#voiceAccountSettingsDlg", subs);
};

ZmVoiceAccountSettingsDlg.prototype._updateBtnHandler = function() {
    var title =  this.zimlet.getMessage("invalidAccountSettings");
    var msg = "";
    var error = false;
    if (!AjxStringUtil.trim(this._passwordField.value)){
        msg = this.zimlet.getMessage("missingPassword");
        error = true;
    }

    if (error){
        this.zimlet.displayErrorMessage(msg, msg,title);
        return false;
    }
    var params = {};
    params.password = this._passwordField.value;
    this._updateAccountSettings(params);
};

ZmVoiceAccountSettingsDlg.prototype._addTabControl = function() {
	this._tabGroup.removeAllMembers();
    this._tabGroup.addMember(this._passwordField, 0);
	this._tabGroup.addMember(this.getButton(DwtDialog.OK_BUTTON), 1);
	this._tabGroup.addMember(this.getButton(DwtDialog.CANCEL_BUTTON), 2);
};


ZmVoiceAccountSettingsDlg.prototype._updateAccountSettings = function(params) {
    params.callback = new AjxCallback(this, this._handleUpdateAccountSettingsResponse, params);
    this.controller._updateAccountSettings(params);
};

ZmVoiceAccountSettingsDlg.prototype._handleUpdateAccountSettingsResponse = function(params) {
    this.popdown();
};