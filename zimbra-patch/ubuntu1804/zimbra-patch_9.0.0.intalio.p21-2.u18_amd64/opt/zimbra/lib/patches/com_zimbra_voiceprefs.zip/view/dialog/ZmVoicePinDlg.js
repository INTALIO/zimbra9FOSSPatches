/*
 * ***** BEGIN LICENSE BLOCK *****
 * Zimbra Collaboration Suite, Network Edition.
 * Copyright (C) 2012, 2013, 2014, 2016 Synacor, Inc.  All Rights Reserved.
 * ***** END LICENSE BLOCK *****
 *
 */

/*
 * Function to change the voice pin for a user
 * The phone with "hasVoicemail" set to true is the voice mailbox
 * The pin is changed on the voice mailbox
 */

ZmVoicePINDlg = function() {
    this.zimlet = ZmVoicePrefs._INSTANCE;
    this.controller = ZmVoicePrefsGeneralController._INSTANCE;
    this._dialogView = new DwtComposite(appCtxt.getShell());
	this._createView();
	var updatePINBtn = new DwtDialog_ButtonDescriptor(ZmVoicePINDlg.UPDATE_PIN_BTN_ID, this.zimlet.getMessage("updatePin"), DwtDialog.ALIGN_RIGHT);

    DwtDialog.call(this, {
        parent: appCtxt.getShell(),
		title: this.zimlet.getMessage("voicePINDlgTitle"),
        view: this._dialogView,
        standardButtons: [DwtDialog.CANCEL_BUTTON],
		extraButtons : [updatePINBtn]
	});
	this.setButtonListener(ZmVoicePINDlg.UPDATE_PIN_BTN_ID, new AjxListener(this, this._updateBtnHandler));
	this._oldpinField = document.getElementById("voicePINDlg_old_PIN_field");
    this._pinField = document.getElementById("voicePINDlg_PIN_field");
	this._confirmPinField = document.getElementById("voicePINDlg_PIN_confirm_field");

	this._addTabControl();

	//regex to check for only-digits
	this.RE = new RegExp("^\\d+$");
};

ZmVoicePINDlg.prototype = new DwtDialog;
ZmVoicePINDlg.prototype.constructor = ZmVoicePINDlg;

ZmVoicePINDlg.UPDATE_PIN_BTN_ID = "voice_pin_dlg_update_btn";
ZmVoicePINDlg.OLD_PIN_FIELD_ID = "voicePINDlg_old_PIN_field";
ZmVoicePINDlg.PIN_FIELD_ID = "voicePINDlg_PIN_field";
ZmVoicePINDlg.CONFIRM_PIN_FIELD_ID = "voicePINDlg_PIN_confirm_field";


ZmVoicePINDlg.prototype._createView = function() {
var subs = {
        oldpinStr: this.zimlet.getMessage("oldPinLabel"),
		pinStr : this.zimlet.getMessage("newPinLabel"),
		confirmPINStr : this.zimlet.getMessage("confirmNewPinLabel"),
        oldpinFieldId : ZmVoicePINDlg.OLD_PIN_FIELD_ID,
		pinFieldId : ZmVoicePINDlg.PIN_FIELD_ID,
		confirmPinFieldId : ZmVoicePINDlg.CONFIRM_PIN_FIELD_ID
	};
	this._dialogView.getHtmlElement().innerHTML =  AjxTemplate.expand("voicemail.VoicePrefs#voicePINDlg", subs);
};

ZmVoicePINDlg.prototype._updateBtnHandler = function() {
    var title =  this.zimlet.getMessage("invalidPin");
    var msg = "";
    var error = false;

    if (this._oldpinField.value == ""){
        msg = this.zimlet.getMessage("missingOldPin");
        error = true;
    }

    if(this._pinField.value == "" && this._confirmPinField.value == "") {
        msg = this.zimlet.getMessage("missingNewPin");
        error = true;
    }

    if(!this.isPINDigits(this._pinField.value)) {
        msg = this.zimlet.getMessage("pinCanOnlyBeDigits");
        error = true;
    }

    if(this._pinField.value != this._confirmPinField.value) {
        msg = this.zimlet.getMessage("pinAndConfirmPinDidntMatch");
        error = true;
    }

    if (error){
        this.zimlet.displayErrorMessage(msg, msg,title);
        return false;
    }
    var params = {};
    params.oldPin = this._oldpinField.value;
    params.newPin = this._pinField.value;
    this._updatePIN(params);
};

ZmVoicePINDlg.prototype._addTabControl = function() {
	this._tabGroup.removeAllMembers();
    this._tabGroup.addMember(this._oldpinField, 0);
	this._tabGroup.addMember(this._pinField, 1);
	this._tabGroup.addMember(this._confirmPinField, 2);
	this._tabGroup.addMember(this.getButton(ZmVoicePINDlg.UPDATE_PIN_BTN_ID), 3);
	this._tabGroup.addMember(this.getButton(ZmVoicePINDlg.CANCEL_BUTTON), 4);
};

ZmVoicePINDlg.prototype.isPINDigits = function(pin) {
	return this.RE.test(pin);
};

ZmVoicePINDlg.prototype._updatePIN = function(params) {
    params.callback = new AjxCallback(this, this._handleUpdatePinResponse, params);
    this.controller.updatePIN(params);
};

ZmVoicePINDlg.prototype._handleUpdatePinResponse = function(params) {
    this.popdown();
};