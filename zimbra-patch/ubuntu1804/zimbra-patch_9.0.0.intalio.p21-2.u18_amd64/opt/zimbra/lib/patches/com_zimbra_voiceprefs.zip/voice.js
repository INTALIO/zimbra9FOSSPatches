/*
 * ***** BEGIN LICENSE BLOCK *****
 * Zimbra Collaboration Suite, Network Edition.
 * Copyright (C) 2012, 2013, 2014, 2016 Synacor, Inc.  All Rights Reserved.
 * ***** END LICENSE BLOCK *****
 */

/**
* Zimlet constructor.
*  @extends ZmZimletBase
*/
ZmVoicePrefs = function () {
	//do nothing
};

ZmVoicePrefs.prototype = new ZmZimletBase;
ZmVoicePrefs.prototype.constructor = ZmVoicePrefs;

ZmVoicePrefs.prototype.init = function() {
	if (!appCtxt.getSettings()._hasVoiceFeature()) {
         return;
    }

    ZmZimletBase.call(this);
    if (!ZmVoicePrefs._INSTANCE){
        ZmVoicePrefs._INSTANCE = this;
    }

	this.sections = {
		VOICE: {
			title: com_zimbra_voiceprefs.voice,
			icon: "VoicemailApp",
			templateId: "voicemail.VoicePrefs#VoicePrefsGeneralView",
			priority: 60,
			precondition: ZmSetting.VOICE_ENABLED,
			prefs: [
				ZmSetting.VOICE_ACCOUNTS
			],
			manageDirty: true,
			createView: function(parent, section, controller) {
				return ZmVoicePrefsGeneralController.getInstance(parent).getListView();
			}
		}
	};
	AjxPackage.require({name: "PreferencesCore", callback: new AjxCallback(this, this._registerPrefs)});
	AjxPackage.require({name: "Voicemail", callback: new AjxCallback(this, this._handleVoicemailLoad)});
    this.getUserUCInfo();
};



ZmVoicePrefs.prototype.toString = function() {
	return "ZmVoicePrefs";
};

ZmVoicePrefs.prototype.getZimlet = function() {
    return ZmVoicePrefs._INSTANCE;
};

ZmVoicePrefs.prototype._registerPrefs = function() {
	for (var id in this.sections) {
		ZmPref.registerPrefSection(id, this.sections[id]);
	}
};

ZmVoicePrefs.prototype.getUserUCInfo = function () {
    var soapDoc = AjxSoapDoc.create("GetUCInfoRequest", "urn:zimbraVoice");
    var respCallback = new AjxCallback(this, this._handleUCInfoResponse);
    var params = {
        soapDoc: soapDoc,
        asyncMode: true,
        noBusyOverlay: true,
        callback: respCallback
    };
    appCtxt.getAppController().sendRequest(params);
};

/*
 * Hand the response
 */
ZmVoicePrefs.prototype._handleUCInfoResponse = function(result) {
    result = result._data;
    if (!result || !result.GetUCInfoResponse) {
        this._popupErrorDlg(this.getMessage("err_failedFetchUCINfo"));
        return;
    }

    var data = result.GetUCInfoResponse;
    if (!data.attrs || !(data.attrs instanceof Array) || data.attrs.length < 1) {
        this._popupErrorDlg(this.getMessage("err_failedFetchUCINfo"));
        return;
    }
    var ucInfo = data.attrs[0]._attrs;
    this.username = ucInfo.zimbraUCUsername;
    this.UC_INFO_LOADED = true;
};

ZmVoicePrefs.prototype._popupErrorDlg = function (msg, ex) {
    var errorDialog = appCtxt.getErrorDialog();
    errorDialog.reset();

    var details = (ex && ex.message) ? ex.message : ex;
    details = AjxUtil.isEmpty(details) ? "" : details;
    errorDialog.setMessage(msg, details, DwtMessageDialog.CRITICAL_STYLE, ZmMsg.zimbraTitle);
    errorDialog.popup();
};


