/**
 * ZmSecureCertificateManager Class
 * @class
 *
 * This class represents certificate management in SMIME preference section
 *
 * @param params
 * @constructor
 */

ZmSecureCertificateManager = function(params) {
    if (!params && !params.type) {
        return;
    }
    DwtComposite.call(this, params);
    this.parent = params.parent || null;
    this.type = params.type && params.type.toUpperCase(); // 'CONTACT', 'PREF'
    this.contact = params.contact || null;
    this._passwordDialog = null; //password dialog modal
    this.uploadCertificateWidget = null; //holds reference to certificate uploader
    //based on type initialize certificate uploader
    switch (this.type) {
        case 'PREF':
            this._initPrefUploader();
            break;
        case 'CONTACT':
            this._initContactUploader();
            break;
        default:
            this._initPrefUploader();
    }
};


ZmSecureCertificateManager.prototype = new DwtComposite();

ZmSecureCertificateManager.prototype.constructor = ZmSecureCertificateManager;

/**
 * Initializes certificate uploader for preference section
 * @private
 */
ZmSecureCertificateManager.prototype._initPrefUploader = function() {
    var uploadCertParams = {
        parent: this.parent,
        type: this.type,
        uploadDoneCallback: new AjxCallback(this, this._saveUserCertificateRequest)
    };
    this.uploadCertificateWidget = new ZmSecureCertificateUpload(uploadCertParams);
};

/**
 * Initialize certificate uploader for contact section
 * @private
 */
ZmSecureCertificateManager.prototype._initContactUploader = function() {
    var uploadCertParams = {
        parent: this.parent,
        hideHelpTextLabel: true,
        type: this.type,
        uploadDoneCallback: new AjxCallback(this, this._saveContactCertificateRequest)
    };
    this.uploadCertificateWidget = new ZmSecureCertificateUpload(uploadCertParams);
};

/**
 * Loads the user's or user's contact's certificate based on type
 */
ZmSecureCertificateManager.prototype.loadCertificate = function() {
    switch (this.type) {
        case 'PREF':
            this._loadUserCertificates();
            break;
        case 'CONTACT':
            this._loadContactCertificate();
            break;
        default:
            this._loadUserCertificates();
    }
};

/**
 * Loads the currently logged-in user's certificate via GetSmimeCertificateInfoRequest API call
 * @private
 */
ZmSecureCertificateManager.prototype._loadUserCertificates = function() {
    this._certificates = null; //reset certificate object
    this.parent.setContent(com_zimbra_securemail.certificateLoadingHelpText);
    var soapDoc = AjxSoapDoc.create('GetSmimeCertificateInfoRequest', "urn:zimbraAccount");
    appCtxt.getAppController().sendRequest({
        soapDoc: soapDoc,
        asyncMode: true,
        callback: new AjxCallback(this, this._handleLoadUserCertificates),
        errorCallback: new AjxCallback(this, this._handleLoadUserCertificatesError)
    });
};

/**
 * Handles the loadUserCertificates API callback
 * @param result
 * @private
 */
ZmSecureCertificateManager.prototype._handleLoadUserCertificates = function(result) {
    this.parent.clear();
    var response = result && result.getResponse && result.getResponse();
    response = response.GetSmimeCertificateInfoResponse;
    if (response && response.certificate) {
        var certificates = response && response.certificate;
        var params = {
            parent: this.parent,
            certificates: certificates,
            type: "PREF",
            removeCertificateHandler: this._confirmRemoveCertificate.bind(this)
        };
        new ZmSecureCertificatePreview(params);
    } else {
        //If no certificates present, show upload certificate widget
        this.uploadCertificateWidget.render();
    }
};

/**
 * Handlers the loadUserCertificates API error
 * @param error
 * @private
 */
ZmSecureCertificateManager.prototype._handleLoadUserCertificatesError = function(exception) {
    this.uploadCertificateWidget.render();
    if (exception && exception.code == ZmCsfeException.SVC_UNKNOWN_DOCUMENT) {
        //Handle UNKNOWN_DOCUMENT error
        //overrides exception's getErrorMsg method to return custom message
        exception.getErrorMsg = function() {
            return com_zimbra_securemail['smime.SERVER_EXTENSION_NOT_INSTALLED'];
        };
    }
};

/**
 * Save certificate request api call
 * @param uploadId
 * @private
 */
ZmSecureCertificateManager.prototype._saveUserCertificateRequest = function(params) {
    if (!params) {
        return new DwtException("Missing Params", DwtException.INVALID_PARAM);
    }
    var soapDoc = AjxSoapDoc.create('SaveSmimeCertificateRequest', "urn:zimbraAccount");
    if (params.uploadId) {
        var uploadElement = soapDoc.set("upload");
        uploadElement.setAttribute('id', params.uploadId);
    }
    if (params.password) {
        soapDoc.set("password", params.password);
    }
    appCtxt.getAppController().sendRequest({
        soapDoc: soapDoc,
        asyncMode: true,
        callback: new AjxCallback(this, this._handleUserSaveCertificateRequest),
        errorCallback: new AjxCallback(this, this._handleUserSaveCertificateException)
    });
};

/**
 * Handle user's save certificate API response
 * @param result
 * @private
 */
ZmSecureCertificateManager.prototype._handleUserSaveCertificateRequest = function(result) {
    this._disposePasswordDialog();
    this._loadUserCertificates();
};

/**
 * Handle save certificate API exception
 * @param result
 * @private
 */
ZmSecureCertificateManager.prototype._handleUserSaveCertificateException = function(exception) {
    var msg = null;
    switch (exception.code) {
        case 'smime.INVALID_CERTIFICATE':
        case 'smime.CERT_VALIDATION_FAILED':
            msg = com_zimbra_securemail.invalidCertificateUploaded;
            break;
        case 'smime.CERT_ALREADY_EXISTS':
            msg = com_zimbra_securemail.duplicateCertificateUploaded;
            break;
        case 'smime.PASSWORD_REQUIRED': {
            //get the uploaded certificate Id
            var requestSOAPDoc = AjxSoapDoc.createFromXml(exception.request).getDoc();
            var uploadTag = requestSOAPDoc.getElementsByTagName('upload')[0];
            //open modal to get the password
            var params = {
                parent: appCtxt.getShell(),
                session: {
                    uploadId: uploadTag.getAttribute('id')
                },
                okCallback: new AjxCallback(this, this._saveUserCertificateRequest.bind(this)),
                cancelCallback: new AjxCallback(this, this._cancelPasswordDialog.bind(this))
            };
            this._passwordDialog = new ZmCertificatePasswordDialog(params);
            this._passwordDialog.popup();
            return true;
        }
            break;
        case 'smime.INVALID_PASSWORD': {
            if (this._passwordDialog) {
                this._passwordDialog.setErrorMsg();
            }
            return true;
        }
            break;
        case ZmCsfeException.SVC_UNKNOWN_DOCUMENT : {
            //Handle UNKNOWN_DOCUMENT error
            exception.getErrorMsg = function() {
                return com_zimbra_securemail['smime.SERVER_EXTENSION_NOT_INSTALLED'];
            };
        }
            break;
        default : {
            msg = exception.msg;
        }
    }

    //reset dialog widget
    this.uploadCertificateWidget.render();
    if (msg) {
        var dialog = appCtxt.getErrorDialog();
        dialog.setMessage(msg, null, DwtMessageDialog.CRITICAL_STYLE);
        dialog.popup(null, true);
        return true;
    }
};

/**
 * Confirms the user certificate removal
 * @param certificate: Certificate object
 * @private
 */
ZmSecureCertificateManager.prototype._confirmRemoveCertificate = function(certificate) {
    var dlg = appCtxt.getYesNoMsgDialog();
    dlg.setMessage(com_zimbra_securemail.certificateRemoveWarning, DwtMessageDialog.WARNING_STYLE);
    switch (this.type) {
        case 'PREF':
            dlg.registerCallback(DwtDialog.YES_BUTTON, this._removeUserCertificate, this, [certificate, dlg]);
            break;
        case 'CONTACT':
            dlg.registerCallback(DwtDialog.YES_BUTTON, this._removeContactCertificate, this, [certificate, dlg]);
            break;
        default:
            dlg.registerCallback(DwtDialog.YES_BUTTON, this._removeUserCertificate, this, [certificate, dlg]);
            break;
    }
    dlg.popup();
};

/**
 * Removes user's SMIME certificate
 * @private
 */
ZmSecureCertificateManager.prototype._removeUserCertificate = function(certificate, dlg) {
    var deleteIds = [];
    certificate.pvtKeyId && deleteIds.push(certificate.pvtKeyId);
    certificate.pubCertId && deleteIds.push(certificate.pubCertId);
    var soapDoc = AjxSoapDoc.create('ItemActionRequest', "urn:zimbraMail");
    var actionElement = soapDoc.set("action");
    actionElement.setAttribute('id', deleteIds.join());
    actionElement.setAttribute('op', "delete");
    appCtxt.getAppController().sendRequest({
        soapDoc: soapDoc,
        asyncMode: true,
        callback: new AjxCallback(this, this._handleRemoveCertificateRequest, [dlg]),
        errorCallback: new AjxCallback(this, this._handleRemoveCertificateError, [dlg])
    });
};

/**
 * Handles remove certificate request
 * @param dlg
 * @private
 */
ZmSecureCertificateManager.prototype._handleRemoveCertificateRequest = function(dlg) {
    dlg.popdown();
    this.uploadCertificateWidget.render();
};

/**
 * Handles remove certificate exception
 * @param dlg
 * @private
 */
ZmSecureCertificateManager.prototype._handleRemoveCertificateError = function(dlg) {
    dlg.popdown();
};

/**
 * Destroy's the Certificate Password Dialog
 * @param dlg
 * @private
 */
ZmSecureCertificateManager.prototype._disposePasswordDialog = function() {
    if (this._passwordDialog) {
        this._passwordDialog.popdown();
        this._passwordDialog = null;
    }
};

/**
 * Loads the user's contact certificate
 * @private
 */
ZmSecureCertificateManager.prototype._loadContactCertificate = function() {
    if (!this.contact) {
        return;
    }
    //check if certificate is present or not
    if (this.contact.certificate) {
        var params = {
            parent: this.parent,
            certificates: this.contact.certificate,
            type: "CONTACT_EDIT",
            removeCertificateHandler: this._confirmRemoveCertificate.bind(this)
        };
        new ZmSecureCertificatePreview(params);
    } else {
        this.uploadCertificateWidget.render();
    }

};

/**
 * Save user's contacts certificate
 * @param params
 * @returns {DwtException}
 * @private
 */
ZmSecureCertificateManager.prototype._saveContactCertificateRequest = function(params) {
    if (!params && !this.contact) {
        return new DwtException("Missing Params", DwtException.INVALID_PARAM);
    }
    var uploadId = params.uploadId;
    var currentView = appCtxt.getCurrentView();
    if (currentView instanceof ZmEditContactView) {
        currentView.newCertificate = uploadId;
        currentView.setDirty("OTHER", true);

        //create certificate selection bubble.
        var params = {
            fileName: params.file.name,
            removeCallback: this._removeCertificateBubbleCallback
        };
        this.uploadCertificateWidget._createSelectionBubble(params);
    }
};

/**
 * Callback when a contact certificate bubble is removed.
 * @private
 */
ZmSecureCertificateManager.prototype._removeCertificateBubbleCallback = function() {
    var currentView = appCtxt.getCurrentView();
    if (currentView instanceof ZmEditContactView) {
        currentView.newCertificate = null;
        currentView.setDirty("OTHER", false);
    }
};

/**
 * Remove user's contacts certificate
 * @param certificate
 * @param dlg
 * @private
 */
ZmSecureCertificateManager.prototype._removeContactCertificate = function(certificate, dlg) {
    dlg.popdown();
    this.uploadCertificateWidget.render();
    var currentView = appCtxt.getCurrentView();
    if (currentView instanceof ZmEditContactView) {
        currentView.newCertificate = null;
        currentView.setDirty("OTHER", true);
    }
};

/**
 * Callback when cancel button is clicked on password dialog
 * @private
 */
ZmSecureCertificateManager.prototype._cancelPasswordDialog = function() {
    this._disposePasswordDialog(); //dispose password dialog on cancel
    this.uploadCertificateWidget.render();
};