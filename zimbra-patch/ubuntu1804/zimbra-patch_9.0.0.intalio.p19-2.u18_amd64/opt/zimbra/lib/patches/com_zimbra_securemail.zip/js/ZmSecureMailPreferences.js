/**
 * Creates a preference section for SecureMail zimlet.
 *
 * @param shell
 * @param section
 * @param controller
 * @param zimletObj
 * @constructor
 */
ZmSecureMailPreferences = function(shell, section, controller, zimletObj) {
    if (!arguments.length) return;
    this._handler = zimletObj;
    this._certificateWidget = null;
    ZmPreferencesPage.call(this, shell, section, controller);
};

ZmSecureMailPreferences.SECURITY = "MAIL_SECURITY_PREF";

AjxDispatcher.addPackageLoadFunction("Preferences", new AjxCallback(function() {

    ZmSecureMailPreferences.prototype = new ZmPreferencesPage;
    ZmSecureMailPreferences.prototype.constructor = ZmSecureMailPreferences;

    ZmSecureMailPreferences.prototype.toString = function() {
        return "ZmSecureMailPreferences";
    };


    /**
     * Assigns settings name array to the object context.
     * @param zimletSettings
     */
    ZmSecureMailPreferences.prototype.setSettingsName = function(zimletSettings) {
        this._settings = zimletSettings;
    };

    /**
     * Returns settings name array of the preference object.
     * @returns {*|Array}
     */
    ZmSecureMailPreferences.prototype.getSettingsName = function() {
        return this._settings || [];
    };

    /**
     * Zimlet architecture hook for post save callback.
     * @returns {AjxCallback}
     */
    ZmSecureMailPreferences.prototype.getPostSaveCallback = function() {
        return new AjxCallback(this, this._doPostSave);
    };

    /**
     * Post save callback handler.
     * @private
     */
    ZmSecureMailPreferences.prototype._doPostSave = function() {
        var settings = this.getSettingsName();
        var zmSettings = appCtxt.getSettings();
        for (var i = 0; i < settings.length; i++) {
            var setting = zmSettings.getSetting(settings[i]);
            var value = setting.getValue();
            this._handler.setUserProperty(setting.id, value);
            setting.origValue = value;
        }
        this._controller.setDirty(this._section.id, false);
        this._handler.saveUserProperties();

    };

    /**
     * Calls when view is shown
     */
    ZmSecureMailPreferences.prototype.showMe = function() {
        ZmPreferencesPage.prototype.showMe.apply(this);
        //init certificate widget
        this._initCertificateWidget();
    };

    /**
     * Initialize certificate widget as DwtComposite
     * @private
     */
    ZmSecureMailPreferences.prototype._initCertificateWidget = function() {
        var id = this.getHTMLElId();
        if (this._certificateWidget && this._certificateWidget instanceof DwtComposite) {
            return;
        }
        this._certificateWidget = new DwtComposite({parent: this});
        this._certificateWidget.reparentHtmlElement(id + "_CertificateContainer");
        var params = {
            parent: this._certificateWidget,
            type: 'PREF'
        };
        var certificate = new ZmSecureCertificateManager(params);
        certificate.loadCertificate();
    };

}));
/**
 * Register SecureMail preference section in the app.
 *
 * It register's individual Preferences along with the complete preference section.
 *
 * @param zimletSettingsNameArray
 * @param zimletObj
 */
ZmSecureMailPreferences.registerPreferences = function registerPreferences(zimletSettingsNameArray, zimletObj) {

    var getLabel = function(key) {
        return com_zimbra_securemail[key];
    };

    ZmPref.registerPref(ZmSecureMailPreferences.SECURITY, {
        displayContainer: ZmPref.TYPE_RADIO_GROUP,
        orientation: ZmPref.ORIENT_VERTICAL,
        displayOptions: [getLabel("prefSecurityAuto"), getLabel("prefSecurityNone"), getLabel("prefSecuritySign"), getLabel("prefSecurityBoth")],
        options: ["auto", "none", "sign", "both"]
    });

    var securityPrefValue = appCtxt.getSettings().getSetting(ZmSecureMailPreferences.SECURITY).getValue();
    ZmPref.setFormValue(ZmSecureMailPreferences.SECURITY, securityPrefValue);

    var prefSection = {
        title: getLabel("prefSection"),
        icon: "ZmSecureEmail",
        templateId: "ZmSecureMail#Preferences",
        priority: 49,
        manageChanges: false,
        manageDirty: true,
        prefs: zimletSettingsNameArray,
        createView: function(parent, sectionObj, controller) {
            var prefObj = new ZmSecureMailPreferences(parent, sectionObj, controller, zimletObj);
            prefObj.setSettingsName(zimletSettingsNameArray);
            return prefObj;
        }
    };
    ZmPref.registerPrefSection("SECURITY", prefSection);
};

/**
 * Register's each of the value from preference section as a ZmSetting in appCtxt.
 * Initializes the settings values as saves in Zimlet user properties.
 * @param zimletObj
 * @returns {Array}
 */
ZmSecureMailPreferences.registerSettings = function(zimletObj) {
    var appSettings = appCtxt.getSettings();
    var zimletSettingsName = [];
    var zimletSettingObj = [];

    var securityPrefSetting = appSettings.registerSetting(ZmSecureMailPreferences.SECURITY, {
        type: ZmSetting.T_PREF,
        dataType: ZmSetting.D_STRING,
        defaultValue: "auto"
    });
    zimletSettingObj.push(securityPrefSetting);
    zimletSettingsName.push(ZmSecureMailPreferences.SECURITY);

    //setting previously value's for pref into ZmSetting objects.
    zimletSettingObj.forEach(function(setting) {
        var savedPropertiyValue = zimletObj.getUserProperty(setting.id);
        setting.setValue(savedPropertiyValue);
    });

    return zimletSettingsName;
};


/**
 * Initialzes the preference settings and sections.
 * Generally called from zimlet object at time on initialization.
 * @param zimletObj
 */
ZmSecureMailPreferences.init = function(zimletObj) {
    ZmSecureMailPreferences.registerPreferences(zimletObj.zimletSettings, zimletObj);
};


