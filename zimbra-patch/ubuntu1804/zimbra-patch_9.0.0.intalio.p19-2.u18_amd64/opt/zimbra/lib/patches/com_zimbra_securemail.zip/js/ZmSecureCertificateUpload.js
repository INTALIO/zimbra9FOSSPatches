/**
 * ZmSecureCertificateUpload Class
 * @class
 *
 * This class represents widget for uploading SMIME certificates
 *
 * @param params
 * @constructor
 */

ZmSecureCertificateUpload = function(params) {
    if (!params) {
        return;
    }
    DwtComposite.call(this, params);
    this.parent = params.parent || null;
    this.type = params.type || null; //'PREF', 'CONTACT'
    this.uploadDoneCallback = params.uploadDoneCallback || null;
    this.uploadStartCallback = params.uploadStartCallback || null;
    this.uploadFailedCallback = params.uploadFailedCallback || null;
    this.hideHelpTextLabel = params.hideHelpTextLabel || false;
    this._browseBtn = null; //browse to certificate button
    this._helpTextLabel = null; //help text label;
    this.bubbleContainer = null; //certificate selection bubble.
    this._validFileTypes = this._getValidFileTypes();
};


ZmSecureCertificateUpload.prototype = new DwtComposite();

ZmSecureCertificateUpload.prototype.constructor = ZmSecureCertificateUpload;

ZmSecureCertificateUpload.TEMPLATE = 'ZmSecureMail#UploadWidget';


/**
 * Render the widget to upload the certificate
 */
ZmSecureCertificateUpload.prototype.render = function() {
    var id = this.getHTMLElId();
    var supportDnD = ZmDragAndDrop.isSupported();
    //valid file types string to be shown in upload widget
    var validFileTypes = this._validFileTypes;
    var lastCommaPost = validFileTypes.lastIndexOf(",");
    //In case there is only one valid file type...don't add 'and' conjunction
    if(lastCommaPost > -1) {
        validFileTypes = "<em>" + validFileTypes.substring(0,lastCommaPost) + "</em> " + com_zimbra_securemail.uploadOptionsAnd + " <em>" + validFileTypes.substring(lastCommaPost + 1) + "</em>";
    } else {
        validFileTypes = "<em>" + validFileTypes + "</em>";
    }
    this.parent._createHtmlFromTemplate(ZmSecureCertificateUpload.TEMPLATE, {
        id: id,
        supportDnD: supportDnD,
        validFileTypes: validFileTypes
    });
    //create browse button
    this._browseBtn = new DwtButton({parent: this.parent});
    this._browseBtn.setText(com_zimbra_securemail.browseBtnLabel);
    this._browseBtn.reparentHtmlElement(id + '_UploadCertificateBtn');
    this._browseBtn.setToolTipContent(com_zimbra_securemail.browseBtnLabel, true);
    this._browseBtn.addSelectionListener(this.showBrowseWindow.bind(this));

    //create help text label
    if (!this.hideHelpTextLabel) {
        this._helpTextLabel = new DwtLabel({parent: this.parent});
        this._helpTextLabel.reparentHtmlElement(id + '_CertificateHelpText');
        this._helpTextLabel.setText(com_zimbra_securemail.certificateHelpText);
    }

    //create drag & drop area if DnD is supported
    if (supportDnD) {
        this.dndContainer = new DwtComposite({parent: this.parent});
        this.dndContainer.replaceElement(id + '_UploadCertificateDnDBtn');
        this.dndContainer.setContent(com_zimbra_securemail.dragDropLabel);
        this.addDragDropHandlers(this.dndContainer.getHtmlElement());
        this.bubbleContainer = this.dndContainer;
    } else {
        this.bubbleContainer = new DwtComposite({parent: this.parent});
        this.bubbleContainer.replaceElement(id + '_certificateBubbleContainer');
    }
};

/**
 * Attaches drag & drop handlers to element el
 * @param el
 */
ZmSecureCertificateUpload.prototype.addDragDropHandlers = function(el) {
    Dwt.setHandler(el, "ondragover", this._onDragOver.bind(this));
    Dwt.setHandler(el, "ondrop", this._onDrop.bind(this));
};

/**
 * Certificate Upload Drag handler
 * @param ev
 * @returns {boolean}
 * @private
 */
ZmSecureCertificateUpload.prototype._onDragOver = function(ev) {
    ev.preventDefault();
    return false;
};

/**
 * Certificate Upload Drop handler
 * @param ev
 * @returns {boolean}
 * @private
 */
ZmSecureCertificateUpload.prototype._onDrop = function(ev) {
    if (ev.stopPropagation) {
        ev.stopPropagation(); // stops the browser from redirecting.
    }

    this._uploadFile(ev.dataTransfer);
    return false;
};

/**
 * Show browse file window.
 * This method will get called when "Browse File" button is clicked
 */
ZmSecureCertificateUpload.prototype.showBrowseWindow = function() {
    if (AjxEnv.supportsHTML5File) {
        var fileInputElement = ZmSecureCertificateUpload.FILE_INPUT;
        if (fileInputElement) {
            fileInputElement.value = "";
        }
        else {
            ZmSecureCertificateUpload.FILE_INPUT = fileInputElement = document.createElement('INPUT');
            fileInputElement.type = "file";
            fileInputElement.title = ZmMsg.uploadNewFile;
            fileInputElement.multiple = false;
            fileInputElement.style.display = "none";
            document.body.appendChild(fileInputElement);
        }
        fileInputElement.accept = this._validFileTypes;
        fileInputElement.onchange = this._uploadFile.bind(this, fileInputElement);
        fileInputElement.click();
    }
};

/**
 * Upload file to server
 * @param files
 * @private
 */
ZmSecureCertificateUpload.prototype._uploadFile = function(files) {
    files = files.files;
    var size = 0;
    if (files.length) {
        for (var j = 0; j < files.length; j++) {
            var file = files[j];
            //Check the total size of the files we upload this time (we don't know the previously uploaded files total size so we do the best we can).
            //NOTE - we compare to the MTA message size limit since there's no limit on specific attachments.
            size += file.size || file.fileSize /*Safari*/ || 0;
            if ((-1 /* means unlimited */ != appCtxt.get(ZmSetting.MESSAGE_SIZE_LIMIT)) &&
                (size > appCtxt.get(ZmSetting.MESSAGE_SIZE_LIMIT))) {
                var msgDlg = appCtxt.getMsgDialog();
                var errorMsg = AjxMessageFormat.format(ZmMsg.attachmentSizeError, AjxUtil.formatSize(appCtxt.get(ZmSetting.MESSAGE_SIZE_LIMIT)));
                msgDlg.setMessage(errorMsg, DwtMessageDialog.WARNING_STYLE);
                msgDlg.popup();
                return false;
            }
        }
        //upload request params
        var params = {
            attachment: false,
            files: files,
            notes: "",
            allResponses: null,
            start: 0,
            curView: null,
            preAllCallback: null,
            initOneUploadCallback: this._handleUploadStart.bind(this, files),
            progressCallback: null,
            errorCallback: this._handleUploadFailed.bind(this, files),
            completeOneCallback: null,
            completeAllCallback: this._handleUploadDone.bind(this, files)
        };

        var uploadManager = appCtxt.getZmUploadManager();
        uploadManager.upload(params);
    }
};

/**
 * Callback that will execute fired when file upload is started
 * @private
 */
ZmSecureCertificateUpload.prototype._handleUploadStart = function(files) {
    this._browseBtn.setEnabled(false);
    if (!this.hideHelpTextLabel) {
        this._helpTextLabel.setText(com_zimbra_securemail.certificateUploadingHelpText);
    }
    //call the uploadStart callback if provided
    this.uploadStartCallback && this.uploadStartCallback.run();
};

/**
 * Callback that will execute when all upload is completed
 * @param allResponses
 * @private
 */
ZmSecureCertificateUpload.prototype._handleUploadDone = function(files, allResponses) {
    var response = allResponses && allResponses[0];
    var file = files && files[0];
    var uploadId = response && response.aid;
    this._browseBtn.setEnabled(true);
    if (uploadId) {
        //save SMIME certificate
        var params = {
            file: file,
            uploadId: uploadId
        };
        //call the uploadDone callback if provided
        this.uploadDoneCallback && this.uploadDoneCallback.run(params);
    }
};

/**
 * Callback that will execute fired when file upload failed
 * @private
 */
ZmSecureCertificateUpload.prototype._handleUploadFailed = function(files) {
    this._browseBtn.setEnabled(true);
    if (!this.hideHelpTextLabel) {
        this._helpTextLabel.setText(com_zimbra_securemail.certificateHelpText);
    }
    //call the uploadFailed callback if provided
    this.uploadFailedCallback && this.uploadFailedCallback.run();
};

/**
 * Creates a new bubble for selected certificate file at contact screen.
 * @param params: Remove bubble callback and uploaded file name.
 * @private
 */
ZmSecureCertificateUpload.prototype._createSelectionBubble = function(params) {
    params["id"] = this.getHTMLElId();

    var bubbleHtml = AjxTemplate.expand("ZmSecureMail#UploadBubble", params);
    this.bubbleContainer.setContent(bubbleHtml);

    //bubble close onClick event handler.
    var bubbleRemoveElement = document.querySelector("#" + this.getHTMLElId() + "_ZmSecureMailUploadContainer .CertificateBubbleClose");
    bubbleRemoveElement && Dwt.setHandler(bubbleRemoveElement, DwtEvent.ONCLICK, this._removeSelectionBubble.bind(this, params));

    //show Save label beside upload elements for contact add/edit.
    var saveUploadCertificateLabel = document.querySelector("#" + this.getHTMLElId() + "_ZmSecureMailUploadContainer .ZmSecureSaveToCompleteLabel");
    Dwt.setDisplay(saveUploadCertificateLabel, Dwt.DISPLAY_TABLE_CELL);
};

/**
 * Callback when bubble is closed.
 * @param params
 * @private
 */
ZmSecureCertificateUpload.prototype._removeSelectionBubble = function(params) {
    //empty the bubble container.
    this.bubbleContainer.clear();

    //reset the DnD container label.
    this.dndContainer && this.dndContainer.setContent(com_zimbra_securemail.dragDropLabel);

    //hide Save label beside upload elements for contact add/edit.
    var saveUploadCertificateLabel = document.querySelector("#" + this.getHTMLElId() + "_ZmSecureMailUploadContainer .ZmSecureSaveToCompleteLabel");
    Dwt.setVisible(saveUploadCertificateLabel, false);
    params.removeCallback && params.removeCallback();
};

/**
 * Get valid file extensions while uploading certificate
 * @returns {string}
 * @private
 */
ZmSecureCertificateUpload.prototype._getValidFileTypes = function() {
    if (this.type) {
        var attr;
        switch (this.type) {
            case 'PREF':
                attr = "zimbraSmimeUserCertificateExtensions";
                break;
            case 'CONTACT':
                attr = "zimbraSmimePublicCertificateExtensions";
                break;
        }
        if (attr) {
            var allAttributes = appCtxt.getSettings().getInfoResponse && appCtxt.getSettings().getInfoResponse.attrs && appCtxt.getSettings().getInfoResponse.attrs._attrs;
            var allowedFileTypes = allAttributes && allAttributes[attr];
            allowedFileTypes = allowedFileTypes instanceof Array ? allowedFileTypes : [allowedFileTypes]; //casting to array
            return allowedFileTypes.map(function(item) {
                return "." + item;
            }).join(", ");
        }
    }
};