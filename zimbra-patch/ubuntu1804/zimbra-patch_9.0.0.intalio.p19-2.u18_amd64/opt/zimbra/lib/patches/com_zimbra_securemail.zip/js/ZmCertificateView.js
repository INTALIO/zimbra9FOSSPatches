/**
 * ZmCertificateView Class
 * @class
 *
 * This class contains API for view Certificate.
 *
 * @param params
 * @constructor
 */

var ZmCertificateView = function() {
};

/**
 * Shows certificate information
 * @param certificate: Certificate object
 * @private
 */

ZmCertificateView._showCertificate = function(certificate) {
    var certificateData = ZmCertificateView.getProcessedCertificate(certificate);
    var dlg = new DwtMessageDialog({parent:appCtxt.getShell()});
    dlg.reset();
    dlg.setTitle(com_zimbra_securemail.certificate);
    var content = AjxTemplate.expand('ZmSecureMail#CertificateDetails', {cert: certificateData});
    dlg.setContent(content);
    dlg.popup();
    //handle invalid/expired certificate case
    if (!certificate.errorCode) {
        var certStatusLabelNode = Dwt.byId('certDialog_certStatusLabel');
        certStatusLabelNode ? certStatusLabelNode.outerHTML = "" : null;
    } else {
        var certStatusLabel = new DwtLabel({parent: this.parent, style: DwtLabel.IMAGE_LEFT});
        certStatusLabel.reparentHtmlElement('certDialog_certStatusLabel');
        switch (certificate.errorCode) {
            case 'CERTIFICATE_NOT_YET_VALID':
                certStatusLabel.setText(com_zimbra_securemail.notYetValidCertificateMsg);
                certStatusLabel.setImage('Invalid');
                break;
            case 'CERTIFICATE_REVOKED':
                certStatusLabel.setText(com_zimbra_securemail.revokedCertificateMsg);
                certStatusLabel.setImage('Invalid');
                break;
            case 'CERTIFICATE_NOT_TRUSTED':
                certStatusLabel.setText(com_zimbra_securemail.untrustedCertificateMsg);
                certStatusLabel.setImage('Invalid');
                break;
            case 'CERTIFICATE_EMAIL_ADDRESS_NOT_MATCHING':
                certStatusLabel.setText(com_zimbra_securemail.certificateEmailInvalidMsg);
                certStatusLabel.setImage('Invalid');
                break;
            case 'INVALID_SIGNATURE':
                certStatusLabel.setText(com_zimbra_securemail.invalidSignatureMsg);
                certStatusLabel.setImage('Invalid');
                break;
            case 'SIGNATURE_VALIDATION_FAILED':
                certStatusLabel.setText(com_zimbra_securemail.signatureValidationFailedMsg);
                certStatusLabel.setImage('Invalid');
                break;
            case 'CERTIFICATE_VALIDATION_FAILED':
            case 'VERIFIER_CERTIFICATE_NOT_VALID':
            case 'SIGNER_INFORMATION_NOT_VERIFIED':
                certStatusLabel.setText(com_zimbra_securemail.invalidCertificateMsg);
                certStatusLabel.setImage('Invalid');
                break;
            case 'CERTIFICATE_EXPIRED':
            case 'VERIFIER_NOT_VALID_AT_SIGNING_TIME':
                certStatusLabel.setText(com_zimbra_securemail.expiredCertificateMsg);
                certStatusLabel.setImage('Invalid');
                break;
        }
    }
};

/**
 * Process the certificate object
 * @param certificate
 * @returns {{}}
 */
ZmCertificateView.getProcessedCertificate = function(certificate) {

    var m = function(key) {
        return com_zimbra_securemail[key] || "";
    };

    var newCertObj = {};
    var subject = newCertObj[m("certSubject")] = {};

    if (certificate.issuedTo) {
        subject[m("certSubjectCN")] = certificate.issuedTo.cn;
        subject[m("certSubjectOrg")] = certificate.issuedTo.o;
        subject[m("certSubjectOrgUnit")] = certificate.issuedTo.ou;
        subject[m("certSubjectEmail")] = certificate.issuedTo.emailAddress;
        subject[m("certSubjectCountry")] = certificate.issuedTo.c;
        subject[m("certSubjectState")] = certificate.issuedTo.st;
        subject[m("certSubjectCity")] = certificate.issuedTo.l;
    }

    if (certificate.issuedBy) {
        var issuer = newCertObj[m("certIssuer")] = {};
        issuer[m("certIssuerCN")] = certificate.issuedBy.cn;
        issuer[m("certIssuerOrg")] = certificate.issuedBy.o;
        issuer[m("certIssuerOrgUnit")] = certificate.issuedBy.ou;
        issuer[m("certIssuerEmail")] = certificate.issuedBy.emailAddress;
        issuer[m("certIssuerCountry")] = certificate.issuedBy.c;
        issuer[m("certIssuerState")] = certificate.issuedBy.st;
        issuer[m("certIssuerCity")] = certificate.issuedBy.l;
    }

    if (certificate.validity) {
        var validity = newCertObj[m("certValidity")] = {};
        validity[m("certValidityBegin")] = ZmCertificateView._formatDate(certificate.validity.startDate);
        validity[m("certValidityEnd")] = ZmCertificateView._formatDate(certificate.validity.endDate);
    }

    if (certificate.signature) {
        var certInfo = newCertObj[m("certInfo")] = {};
        certInfo[m("certInfoSN")] = certificate.signature.serialNo;
        certInfo[m("certInfoAlg")] = ZmCertificateView._formatAlgorithm(certificate.signature.algorithm);
    }

    var certSubjectAltName = certificate.subjectAltName;
    if (certSubjectAltName) {

        var subjectAltName = newCertObj[m("subjectAltName")] = {};
        var subjectAltNameAttr = ['otherName', 'rfc822Name', 'dNSName', 'x400Address', 'directoryName', 'ediPartyName', 'uniformResourceIdentifier', 'iPAddress', 'registeredID'];

        AjxUtil.foreach(subjectAltNameAttr, function(value, index){
            ZmCertificateView.getSubjectAltNameAttrValues(certSubjectAltName, value, subjectAltName);
        });
    }

    ZmCertificateView._removeEmptyLeaves(newCertObj);
    return newCertObj;
};

ZmCertificateView.getSubjectAltNameAttrValues = function(certSubjectAltName, attribute, subjectAltName) {

    if (certSubjectAltName[attribute]) {
        var attributeArr = certSubjectAltName[attribute];
        AjxUtil.foreach(attributeArr, function(value,index) {
            if (index === 0) {
                subjectAltName[com_zimbra_securemail['subjectAltName'+attribute]] = value._content;
            } else {
                subjectAltName[attribute+ "blank" + index] = value._content;
            }
        });
    }
};

ZmCertificateView._formatDate = function(msec) {
    return msec && AjxDateUtil.longComputeDateStr(new Date(msec));
};

ZmCertificateView._formatAlgorithm = function(str) {
    str = str.replace(/([A-Z])([a-z])/g, function(str, p1, p2) {
        return " " + str
    });
    str = str.replace(/([a-z])([A-Z])/g, function(str, p1, p2) {
        return p1 + " " + p2
    });
    return str;
};

ZmCertificateView._removeEmptyLeaves = function(obj) {
    for (var key in obj) {
        var value = obj[key];
        if (!value) {
            delete obj[key];
        } else if (AjxUtil.isObject(value)) {
            ZmCertificateView._removeEmptyLeaves(value);
        }
    }
};