/*
 * ***** BEGIN LICENSE BLOCK *****
 * Zimbra Collaboration Suite Web Client
 * Copyright (C) 2011, 2012, 2013, 2014, 2015, 2016 Synacor, Inc.  All Rights Reserved.
 * ***** END LICENSE BLOCK *****
 */

/**
 * Handler object for Zimlet
 * @constructor
 */
function ZmSecureMail() {
    this._patchedFcts = {};
    this._active = false;
};

ZmSecureMail.prototype = new ZmZimletBase();

ZmSecureMail.prototype.constructor = ZmSecureMail;

ZmSecureMail.SECUREMAIL_SECURITY_BUTTON_CLASS = "com_zimbra_securemail";
ZmSecureMail.SECUREMAIL_PREF_SECURITY = "MAIL_SECURITY_PREF";
ZmSecureMail.SECUREMAIL_USER_SECURITY = "MAIL_USER_SECURITY";
ZmSecureMail.SECUREMAIL_DONTSIGN = "none";
ZmSecureMail.SECUREMAIL_SIGN = "sign";
ZmSecureMail.SECUREMAIL_SIGNENCRYPT = "both";
ZmSecureMail.SECUREMAIL_SECURITY_TYPES = {
    "none": {
        label: com_zimbra_securemail.dontSignMessage,
        className: "DontSign"
    },
    "sign": {
        label: com_zimbra_securemail.signMessage,
        className: "Sign"
    },
    "both": {
        label: com_zimbra_securemail.signAndEncryptMessage,
        className: "SignEncrypt"
    }
};

/**
 * Init function, will be called automatically by Zimlet framework
 */
ZmSecureMail.prototype.init = function() {

    //If mail is not enabled, return
    if (!appCtxt.get(ZmSetting.MAIL_ENABLED) || !this._hasSMIMEFeature())
        return;

    this._active = true;

    //Bug ZCS-648
    //Because ZmSecureMailPreferences loads when Preferences package loaded, settings were not registered when this zimlet loaded
    //Hence registering zimlet setting onInit
    this.zimletSettings = ZmSecureMailPreferences.registerSettings(this);

    //Callback function to run when the MailCore module is loaded
    AjxDispatcher.addPackageLoadFunction("MailCore", new AjxCallback(this, this._handleMailCoreLoad));
    AjxDispatcher.addPackageLoadFunction("ContactsCore", new AjxCallback(this, this._handleContactsLoad));
    AjxDispatcher.addPackageLoadFunction("Preferences", new AjxCallback(this, this._handlePreferencesLoad));
    //handles new window load event
    if (appCtxt.isChildWindow) {
        //In case of new window, Zimlets are loaded first, so this is ideal place to ensure that this code runs before new window view is rendered
        this._handleNewWindowLoad();
    }
    //update ZmMsg object with new properties
    this._updateZmMsg();
    //handle lazy loading of Zimlet
    this._handleLazyLoad();
};

ZmSecureMail.prototype.toString = function() {
    return "ZmSecureMail";
};

/**
 * Checks if SMIME feature is enabled or not
 * @returns {boolean}
 * @private
 */
ZmSecureMail.prototype._hasSMIMEFeature = function() {
    var status = appCtxt.get(ZmSetting.LICENSE_STATUS);

    if (ZmSetting.LICENSE_MSG[status])
        return false;

    // check for S/MIME license attribute
    var license = appCtxt.getSettings().getInfoResponse.license;

    for (var i = 0; license && i < license.attr.length; i++) {
        var attr = license.attr[i];

        if (attr.name == "SMIME")
            return attr._content == "TRUE";
    }
    return false;
};

/**
 * This method is called by the Zimlet framework when application toolbars are initialized.
 * {ZmApp} app the application
 * {ZmButtonToolBar} toolbar the toolbar
 * {ZmController} controller the application controller
 * {string} viewId the view Id
 */
ZmSecureMail.prototype.initializeToolbar = function(app, toolbar, controller, viewId) {
    //if zimlet is not active - return
    if (!this._active) {
        return;
    }

    if (viewId.indexOf("COMPOSE") != -1) {
        var button;
        var children = toolbar.getChildren();
        for (var i = 0; i < children.length && !button; i++) {
            if (Dwt.hasClass(children[i].getHtmlElement(), ZmSecureMail.SECUREMAIL_SECURITY_BUTTON_CLASS)) {
                button = children[i];
                break;
            }
        }
        var selectedValue;
        var enableSecurityButton = true;
        selectedValue = this._getSecuritySetting();
        if (!button) {
            var index = AjxUtil.indexOf(toolbar.opList, ZmOperation.COMPOSE_OPTIONS) + 1;
            var id = Dwt.getNextId() + "_" + ZmSecureMail.SECUREMAIL_SECURITY_BUTTON_CLASS;

            //Create a toolbar button
            var securityButton = new DwtToolBarButton({
                parent: toolbar,
                id: id + '_checkbox',
                index: index,
                className: ZmSecureMail.SECUREMAIL_SECURITY_BUTTON_CLASS + ' ZToolbarButton'
            });

            //create new menu item with security button as parent
            var securityMenu = new DwtMenu({
                parent: securityButton,
                id: id + '_menu',
                className: 'DwtMenu ZmSecureMailComposeMenu'
            });
            var signingRadioId = id + "_menu_sign";

            //set menu item of security button
            securityButton.setMenu(securityMenu);

            //register listener
            var listener = new AjxListener(this, this._handleSelectSigning, [securityButton]);

            var noSignButton = new DwtMenuItem({
                parent: securityMenu,
                style: DwtMenuItem.RADIO_STYLE,
                radioGroupId: signingRadioId
            });
            noSignButton.setText(com_zimbra_securemail.dontSignMessage);
            noSignButton.setImage(ZmSecureMail.SECUREMAIL_SECURITY_TYPES["none"].className);
            noSignButton.addSelectionListener(listener);
            noSignButton.setData("sign", ZmSecureMail.SECUREMAIL_DONTSIGN);

            var signButton = new DwtMenuItem({
                parent: securityMenu,
                style: DwtMenuItem.RADIO_STYLE,
                radioGroupId: signingRadioId
            });
            signButton.setText(com_zimbra_securemail.signMessage);
            signButton.setImage(ZmSecureMail.SECUREMAIL_SECURITY_TYPES["sign"].className);
            signButton.addSelectionListener(listener);
            signButton.setData("sign", ZmSecureMail.SECUREMAIL_SIGN);

            var signAndEncryptButton = new DwtMenuItem({
                parent: securityMenu,
                style: DwtMenuItem.RADIO_STYLE,
                radioGroupId: signingRadioId
            });
            signAndEncryptButton.setText(com_zimbra_securemail.signAndEncryptMessage);
            signAndEncryptButton.setImage(ZmSecureMail.SECUREMAIL_SECURITY_TYPES["both"].className);
            signAndEncryptButton.addSelectionListener(listener);
            signAndEncryptButton.setData("sign", ZmSecureMail.SECUREMAIL_SIGNENCRYPT);

            securityMenu.checkItem("sign", selectedValue, true);
            this._setSecurityImage(securityButton, selectedValue);
            securityButton.setEnabled(enableSecurityButton);

        } else {
            var menu = button.getMenu();
            if (menu) {
                menu.checkItem("sign", selectedValue, true);
                this._setSecurityImage(button, selectedValue);
            }
            button.setEnabled(enableSecurityButton);
        }
    }
};

/**
 * Get the dropdown value based on user preference
 * @returns {*}
 * @private
 */
ZmSecureMail.prototype._getSecuritySetting = function() {

    if (appCtxt.isChildWindow) {
        return window.opener.appCtxt.getZimletMgr().getZimletByName('com_zimbra_securemail').handlerObject._getUserSecuritySetting();
    } else {
        var setting = appCtxt.get(ZmSecureMail.SECUREMAIL_PREF_SECURITY);
        if (setting == "auto") {
            return this.getUserProperty(ZmSecureMail.SECUREMAIL_USER_SECURITY) || ZmSecureMail.SECUREMAIL_DONTSIGN;
        } else {
            return setting;
        }
    }
};

/**
 * Gets the user security settings
 * @param controller
 * @param useToolbarOnly
 * @returns {*}
 * @private
 */
ZmSecureMail.prototype._getUserSecuritySetting = function(controller, useToolbarOnly) {
    var app = appCtxt.getApp("Mail");
    AjxDispatcher.require(["MailCore", "Mail"]);
    var view = appCtxt.getAppViewMgr().getCurrentView();
    controller = controller || (view && view.isZmComposeView && view.getController());
    if (!useToolbarOnly) {
        controller = controller || app.getComposeController(app.getCurrentSessionId("COMPOSE"));
    }
    var toolbar = controller && controller._toolbar;
    var button = toolbar && this._getSecurityButtonFromToolbar(toolbar);
    var menu = button && button.getMenu();

    if (menu) {
        return menu.getSelectedItem().getData("sign");
    } else if (useToolbarOnly) {
        //only local setting is requested.
        return false;
    } else {
        return this._getSecuritySetting();
    }
};

/**
 * Selects the security button
 * @param toolbar
 * @returns {*}
 * @private
 */
ZmSecureMail.prototype._getSecurityButtonFromToolbar = function(toolbar) {
    var children = toolbar.getChildren();
    for (var i = 0; i < children.length; i++) {
        if (Dwt.hasClass(children[i].getHtmlElement(), ZmSecureMail.SECUREMAIL_SECURITY_BUTTON_CLASS)) {
            return children[i];
        }
    }
};

/**
 * Set the menu button style based on user selected value
 * @private
 */
ZmSecureMail.prototype._setSecurityImage = function(button, value) {
    value = value || ZmSecureMail.SECUREMAIL_DONTSIGN;
    button.setImage(ZmSecureMail.SECUREMAIL_SECURITY_TYPES[value].className);
    button.setText(ZmSecureMail.SECUREMAIL_SECURITY_TYPES[value].label);
};

/**
 * Callback to run when the drop menu item is selected
 * @param securityButton
 * @param evt
 * @private
 */
ZmSecureMail.prototype._handleSelectSigning = function(securityButton, evt) {
    //store the user selected value in preference
    var value = evt.dwtObj.getData("sign");
    this._setSecurityImage(securityButton, value);
    this.setUserProperty(ZmSecureMail.SECUREMAIL_USER_SECURITY, value);
    this.saveUserProperties();

    //save the draft
    var view = appCtxt.getCurrentView();
    var composeCtrl = view && view.getController && view.getController();
    composeCtrl.saveDraft(ZmComposeController.DRAFT_TYPE_AUTO);

    //handle case for send later case
    this._manageSendLaterButton();
};

/**
 * Checks if user has selected sign or sign and encrypt option
 * @returns {boolean}
 * @private
 */
ZmSecureMail.prototype._shouldSign = function() {
    var selectedVal = this._getUserSecuritySetting();
    return selectedVal == ZmSecureMail.SECUREMAIL_SIGN || selectedVal == ZmSecureMail.SECUREMAIL_SIGNENCRYPT;
};

/**
 * Checks if user has selected encrypt option
 * @returns {boolean}
 * @private
 */
ZmSecureMail.prototype._shouldEncrypt = function() {
    return this._getUserSecuritySetting() == ZmSecureMail.SECUREMAIL_SIGNENCRYPT;
};

/**
 * Callback function which will run when MailCore module is loaded
 * @private
 */
ZmSecureMail.prototype._handleMailCoreLoad = function() {
    this._handleZmMailMsgLoad();
};

/**
 * Overrides several functions when ZmMailMsg module is loaded
 * @private
 */
ZmSecureMail.prototype._handleZmMailMsgLoad = function() {
    var self = this;
    //override _sendMessage method to add sign and encrypt params
    this.override("ZmMailMsg.prototype._sendMessage", function cb(params) {
        self._sendMessage(cb.func, this, params);
    });
    //handle callback response
    this.override("ZmMailMsg.prototype._handleResponseSendMessage", function cb(params, result) {
        self._handleResponseSendMessage(cb.func, this, params, result);
    });
    //override _loadFromDom method to include certificate in ZmMailMsg object
    this.override("ZmMailMsg.prototype._loadFromDom", function cb(msgNode) {
        self._loadMsgFromDom(cb.func, this, msgNode);
    });
};

/**
 * Overrides the ZmMailMsg.prototype._sendMessage method.
 * It checks if sign or encrypt option is selected, if so,
 * it forwards the request to SendSecureMsgRequest, else
 * resumes the normal operation
 *
 * @param originalFunc
 * @param obj
 * @param params
 * @private
 */
ZmSecureMail.prototype._sendMessage = function(originalFunc, obj, params) {
    //get the user selected preferences
    var sign = this._shouldSign();
    var encrypt = this._shouldEncrypt();

    if ((sign || encrypt) && params.jsonObj.SendMsgRequest && appCtxt.getCurrentAppName() == ZmId.APP_MAIL) {
        var originalRequest = params.jsonObj.SendMsgRequest;
        delete params.jsonObj.SendMsgRequest;
        params.jsonObj.SendSecureMsgRequest = originalRequest;
        params.jsonObj.SendSecureMsgRequest.sign = sign ? "true" : "false";
        params.jsonObj.SendSecureMsgRequest.encrypt = encrypt ? "true" : "false";
    }
    originalFunc.apply(obj, [params]);
};

/**
 * Overrides the ZmMailMsg.prototype._handleResponseSendMessage method,
 * for parsing response for SendSecureMsgResponse api
 *
 * @param originalFunc
 * @param obj
 * @param params
 * @param result
 * @private
 */
ZmSecureMail.prototype._handleResponseSendMessage = function(originalFunc, obj, params, result) {
    if (params.jsonObj.SendSecureMsgRequest) {
        var response = result.getResponse();
        result.set(response.SendSecureMsgResponse);
        if (params.callback) {
            params.callback.run(result);
        }
    } else {
        originalFunc.call(obj, params, result);
    }
};

/**
 * Overrides the ZmMailMsg.prototype._loadFromDom method,
 * for parsing response for GetMsgResponse api to include certificate and other information
 *
 * @param originalFunc
 * @param obj
 * @param msgNode
 * @private
 */
ZmSecureMail.prototype._loadMsgFromDom = function(originalFunc, obj, msgNode) {
    originalFunc.call(obj, msgNode);
    if (msgNode.certificate) {
        obj.certificate = msgNode.certificate;
    }
    if (msgNode.isSigned) {
        obj.isSigned = msgNode.isSigned == "true";
    }
    if (msgNode.isEncrypted) {
        obj.isEncrypted = msgNode.isEncrypted == "true";
    }
    if (msgNode.decryptionErrorCode) {
        obj.decryptionErrorCode = msgNode.decryptionErrorCode;
    }
};

/**
 * Utility function to over-ride function definition
 * @param origFctStr
 * @param newFct
 * @param forceNew
 */
ZmSecureMail.prototype.override = function(origFctStr, newFct, forceNew) {
    if (this._patchedFcts[origFctStr] && !forceNew) {
        // Function is already overridden - hence not doing it again
        return;
    } else if (!newFct) {
        //New function is not defined...return
        return;
    }
    var path = origFctStr.split(".");
    var object = window;
    for (var i = 0; i < path.length - 1; i++) {
        object = object[path[i]];
        if (!object) {
            // The path doesn't exist
            return;
        }
    }

    var fctName = path[path.length - 1];
    var oldFct = object[fctName];

    if (oldFct) {
        //override old function
        object[fctName] = function() {
            newFct.func = oldFct;
            return newFct.apply(this, arguments);
        };
        this._patchedFcts[origFctStr] = true;
    }
};


/**
 * This method is called by Zimlet framework when any view is shown
 *
 * @param view
 */
ZmSecureMail.prototype.onShowView = function(view) {
    //if zimlet is not active - return
    if (!this._active) {
        return;
    }
    if (view.indexOf('COMPOSE') != -1) {
        this._manageSendLaterButton();
    } else if (view.indexOf(ZmId.VIEW_CONTACT_SIMPLE) != -1) {
        //Bug ZCS-636 fix
        //re-render contact to show certificate, as removing tag from contact clears entire parent markup
        var currentView = appCtxt.getCurrentView();
        var controller = appCtxt.getCurrentController();
        if (!currentView._contact) {
            return;
        }
        var contact = currentView._contact;
        if (contact.certificate) {
            currentView.setContact(contact, controller.isGalSearch());
        }
    }
};

/**
 * This function disables "Send Later" button while composing new
 * message in-case user has selected to sign or encrypt a mail
 *
 * @private
 */
ZmSecureMail.prototype._manageSendLaterButton = function() {
    var sendLaterEnabled = appCtxt.get(ZmSetting.MAIL_SEND_LATER_ENABLED);
    if (sendLaterEnabled) {
        var controller = appCtxt && appCtxt.getCurrentController();
        var toolbar = controller && controller._toolbar;
        var sendMenu = toolbar.getButton(ZmId.OP_SEND_MENU).getMenu();
        var sendLaterBtn = sendMenu.getMenuItem(ZmId.OP_SEND_LATER);
        var selectedSecuritySetting = this._getUserSecuritySetting();
        if (selectedSecuritySetting != ZmSecureMail.SECUREMAIL_DONTSIGN) {
            sendLaterBtn.setEnabled(false);
        } else {
            sendLaterBtn.setEnabled(true);
        }
    }
};

/**
 * This method is called by Zimlet framework when mail message is shown
 * @param msg
 * @param oldMsg
 * @param msgView
 */

ZmSecureMail.prototype.onMsgView = function(msg, oldMsg, msgView) {
    //if zimlet is not active - return
    if (!this._active) {
        return;
    }
    if (msg && msg.type == ZmId.ITEM_MSG) {
        if ((msg.isSigned || msg.isEncrypted) && !msg.decryptionErrorCode) {
            var mailHeaderId = msgView._hdrTableId;
            if (!mailHeaderId) {
                return;
            }
            var headerContainer = Dwt.byId(mailHeaderId);
            var row = headerContainer.insertRow();
            var labelCell = row.insertCell(0);
            var contentCell = row.insertCell(1);
            labelCell.innerHTML = com_zimbra_securemail.security + ':';
            labelCell.className = 'LabelColName';
            contentCell.className = 'LabelColValue ZmSecureMailCertificateRow';
            var certificateRow = new DwtComposite({
                parent: msgView
            });
            certificateRow.reparentHtmlElement(contentCell);
            var params = {
                parent: certificateRow,
                type: 'MSG',
                certificates: msg.certificate || [],
                isSigned: msg.isSigned,
                isEncrypted: msg.isEncrypted
            };
            new ZmSecureCertificatePreview(params);
        } else if (msg.decryptionErrorCode) {
            var mailHeaderId = msgView._hdrTableId;
            if (!mailHeaderId) {
                return;
            }
            var headerContainer = Dwt.byId(mailHeaderId);
            var row = headerContainer.insertRow();
            var labelCell = row.insertCell(0);
            var contentCell = row.insertCell(1);
            labelCell.innerHTML = com_zimbra_securemail.security + ':';
            labelCell.className = 'LabelColName';
            contentCell.className = 'LabelColValue ZmSecureMailCertificateRow';
            var errorMsgRow = new DwtLabel({
                parent: msgView,
                style: DwtLabel.IMAGE_LEFT,
                className: "invalid_cert_wrapper"
            });
            errorMsgRow.reparentHtmlElement(contentCell);
            errorMsgRow.setImage('Invalid');
            errorMsgRow.setText(com_zimbra_securemail["decryptionError." + msg.decryptionErrorCode] || com_zimbra_securemail["decryptionError.DECRYPTION_FAILED"]);
        }
        this._hideRemoveAttachmentLinks(msg, msgView);
    }
};

/**
 * This method is called by Zimlet framework when message in conversation is expanded
 * @param msg
 * @param msgView
 */
ZmSecureMail.prototype.onMsgExpansion = function(msg, msgView) {
    this.onMsgView(msg, null, msgView);
};

/**
 * Overrides several functions when ZmContact module is loaded
 * @private
 */
ZmSecureMail.prototype._handleContactsLoad = function() {
    var self = this;
    //override ZmContact.prototype._addRequestAttr to include userCertificate in request params
    this.override("ZmContact.prototype._addRequestAttr", function cb(cn, name, value) {
        return self._addContactRequestAttr(cb.func, this, cn, name, value);
    });
    //override ZmEditContactView.prototype.getModifiedAttrs to return the updated modified userCertificate attribute
    this.override("ZmEditContactView.prototype.getModifiedAttrs", function cb() {
        return self._getContactModifiedAttrs(cb.func, this);
    });
    //override ZmEditContactView.prototype.__initRowsOther to hides the custom userCertificate field
    this.override("ZmEditContactView.prototype.__initRowsOther", function cb(nattrs, id, prefixes, onlyvalue, listAttrs) {
        return self.__initContactRowsOther(cb.func, this, nattrs, id, prefixes, onlyvalue, listAttrs);
    });
    //override _loadFromDom method to include certificate object in ZmMailMsg object
    this.override("ZmContact.prototype._loadFromDom", function cb(node) {
        self._loadContactFromDom(cb.func, this, node);
    });
    //override ZmContact.createFromDom static method to include certificate object in cached contact object
    this.override("ZmContact.createFromDom", function cb(node, args) {
        return self._createContactFromDom(cb.func, node, args);
    });
    //override ZmContactSplitView._showContactListItem to hides the custom userCertificate field
    this.override("ZmContactSplitView._showContactListItem", function cb(itemListData) {
        return self._showContactListItem(cb.func, this, itemListData);
    });
};

/**
 * Overrides ZmContact.prototype._addRequestAttr to include userCertificate in request params
 * @param originalFunc
 * @param obj
 * @param cn
 * @param name
 * @param value
 * @private
 */
ZmSecureMail.prototype._addContactRequestAttr = function(originalFunc, obj, cn, name, value) {
    if (name == 'userCertificate' && AjxUtil.isString(value) && value.length) {
        if (value.indexOf("aid_") != -1) {
            var a = {
                n: name
            };
            a.aid = value.substring(4);
            cn.a.push(a);
        } else {
            originalFunc.call(obj, cn, name, value);
        }
    } else {
        originalFunc.call(obj, cn, name, value);
    }
};

/**
 * Overrides ZmEditContactView.prototype.getModifiedAttrs to return the updated modified userCertificate attribute
 * @param originalFunc
 * @param obj
 * @returns {*|{}}
 */
ZmSecureMail.prototype._getContactModifiedAttrs = function(originalFunc, obj) {
    var mod = originalFunc.call(obj) || {};
    if (obj.newCertificate) {
        mod["userCertificate"] = "aid_" + obj.newCertificate;
    } else if (obj.newCertificate === null) {
        mod["userCertificate"] = "";
    }
    return mod;
};

/**
 * Overrides ZmEditContactView.prototype.__initRowsOther to hides the custom userCertificate field
 * @param originalFunc
 * @param obj
 * @param nattrs
 * @param id
 * @param prefixes
 * @param onlyvalue
 * @param listAttrs
 * @returns {*}
 * @private
 */
ZmSecureMail.prototype.__initContactRowsOther = function(originalFunc, obj, nattrs, id, prefixes, onlyvalue, listAttrs) {
    var cp_nattrs = AjxUtil.hashCopy(nattrs);
    delete cp_nattrs["userCertificate"];
    return originalFunc.call(obj, cp_nattrs, id, prefixes, onlyvalue, listAttrs);
};

/**
 * Overrides _loadFromDom method to include certificate object in ZmMailMsg object
 * @param originalFunc
 * @param obj
 * @param node
 * @private
 */
ZmSecureMail.prototype._loadContactFromDom = function(originalFunc, obj, node) {
    if(!(obj instanceof ZmContact)) {
        return;
    }
    originalFunc.call(obj, node);
    if (node.certificate) {
        obj.certificate = node.certificate;
    }
    //add custom update listener
    var updateContactListener = new AjxListener(this, this._onContactUpdate);
    obj.addChangeListener(updateContactListener);
};

/**
 * Override ZmContact.createFromDom static method to include certificate object in cached contact object
 * @param originalFunc
 * @param node
 * @param args
 * @returns {Object}
 * @private
 */
ZmSecureMail.prototype._createContactFromDom = function(originalFunc, node, args) {
    originalFunc(node, args);
    var contact = appCtxt.cacheGet(node.id);
    if (contact && node.certificate) {
        contact.certificate = node.certificate;
        //add custom update listener
        var updateContactListener = new AjxListener(this, this._onContactUpdate);
        contact.addChangeListener(updateContactListener);
    }
    return contact;
};

/**
 * Overrides ZmContactSplitView._showContactListItem to hides the custom userCertificate field
 * @param originalFunc
 * @param obj
 * @param itemListData
 * @returns {*}
 * @private
 */
ZmSecureMail.prototype._showContactListItem = function(originalFunc, obj, itemListData) {
    if (itemListData.name == "userCertificate") {
        return "";
    } else {
        return originalFunc.call(obj, itemListData);
    }
};

/**
 * This method is called by Zimlet framework when contact is shown
 * @param contact
 * @param elementId
 */
ZmSecureMail.prototype.onContactView = function(contact, elementId) {
    //if zimlet is not active - return
    if (!this._active) {
        return;
    }
    if (appCtxt.getCurrentViewType() != ZmId.VIEW_CONTACT_SIMPLE && !contact.certificate) {
        return;
    }
    var contactDetailId = appCtxt && appCtxt.getCurrentView && appCtxt.getCurrentView()._detailsId;
    if (!contactDetailId) {
        return;
    }
    var headerRow = Dwt.byClassName('headerRow', Dwt.byId(contactDetailId));
    headerRow = headerRow && headerRow[0];
    headerRow = Dwt.byClassName('rowValue', headerRow);
    headerRow = headerRow && headerRow[0];
    var certificateRow = new DwtComposite({
        parent: appCtxt.getCurrentView(),
        className: 'contactHeaderCertRow'
    });
    certificateRow.reparentHtmlElement(headerRow);
    var params = {
        type: 'CONTACT_VIEW',
        parent: certificateRow,
        certificates: contact.certificate
    };
    new ZmSecureCertificatePreview(params);
};

/**
 * This method is called by Zimlet framework when contact is edited
 * @param view
 * @param contact
 * @param elementId
 */
ZmSecureMail.prototype.onContactEdit = function(view, contact, elementId) {
    //if zimlet is not active - return
    if (!this._active) {
        return;
    }
    var emailEl = Dwt.byId(view.getHTMLElId() + "_EMAIL");
    var emailTr = emailEl.parentNode.parentNode;
    var tableEl = emailTr.parentNode.parentNode;
    var row = tableEl.insertRow(emailTr.rowIndex + 1);
    var labelCell = row.insertCell(0);
    var contentCell = row.insertCell(1);
    labelCell.innerHTML = com_zimbra_securemail.certificate + ':';
    labelCell.className = 'rowLabel';
    contentCell.className = 'rowValue';
    var certificateRow = new DwtComposite({
        parent: view
    });
    certificateRow.reparentHtmlElement(contentCell);
    var params = {
        parent: certificateRow,
        contact: contact,
        type: 'CONTACT'
    };
    var certificate = new ZmSecureCertificateManager(params);
    certificate.loadCertificate();
};

/**
 * This is listener method that will get called when contact is updated
 * @param evt
 * @private
 */
ZmSecureMail.prototype._onContactUpdate = function(evt) {
    if (evt.type != ZmId.ITEM_CONTACT || evt.event != ZmEvent.E_MODIFY) {
        return;
    }
    if (evt._details && evt._details._attrs && evt._details._attrs.userCertificate) {
        evt.item.certificate = evt._details.certificate;
    } else if (evt.item.getAttr && evt.item.getAttr('userCertificate') == "") {
        evt.item.certificate = null;
    }
};

/**
 * Overrides several functions when new window is loaded
 * @private
 */
ZmSecureMail.prototype._handleNewWindowLoad = function() {
    var self = this;
    //override ZmNewWindow.prototype._deepCopyMsg to include certificate object in ZmMailMsg object of new window
    this.override("ZmNewWindow.prototype._deepCopyMsg", function cb(msg) {
        return self._deepCopyMsgForNewWindow(cb.func, this, msg);
    })
};

/**
 * Overrides ZmNewWindow.prototype._deepCopyMsg method to include certificate object in new windpw
 * @param originalFunc
 * @param obj
 * @param msg
 * @returns {*}
 * @private
 */
ZmSecureMail.prototype._deepCopyMsgForNewWindow = function(originalFunc, obj, msg) {
    var newMsg = originalFunc.call(obj, msg);
    //check if certificate is present in original Msg object, if so, incldue it in newMsg object
    if (msg.certificate) {
        newMsg.certificate = msg.certificate;
    }
    return newMsg;
};

/**
 * Append global ZmMsg object with new properties
 * @private
 */
ZmSecureMail.prototype._updateZmMsg = function() {
    if (!window.ZmMsg) {
        ZmMsg = {};
    }
    var newKeys = [
        'smime.ENCRYPTION_FAILED',
        'smime.SIGNING_FAILED',
        'smime.RECIPIENT_SMIME_CERT_NOT_FOUND',
        'smime.MSG_ENCRYPTION_FAILED',
        'smime.MSG_SIGNING_FAILED',
        'smime.LOAD_CERTIFICATE_FAILED',
        'smime.USER_CERT_NOT_YET_VALID',
        'smime.CERT_VALIDATION_FAILED',
        'smime.USER_CERT_EXPIRED',
        'smime.USER_CERT_REVOKED',
        'smime.USER_CERT_EMAIL_ADDRESS_NOT_MATCHING',
        'smime.USER_CERT_NOT_TRUSTED',
        'smime.OPERATION_DENIED',
        'smime.DELEGATE_SEND_SECURE_PERM_DENIED'
    ];

    newKeys.forEach(function(val) {
        ZMsg[val] = com_zimbra_securemail[val]
    });
};

/**
 * This method is called by Zimlet framework when message sending fails.
 * @param obj
 * @param ex
 * @param msg
 */
ZmSecureMail.prototype.onSendMsgFailure = function(obj, ex, msg) {
    var errorCode = ex && ex.code;
    if (errorCode) {
        var certErrorCodes = [
            'smime.LOAD_CERTIFICATE_FAILED',
            'smime.USER_CERT_NOT_YET_VALID',
            'smime.CERT_VALIDATION_FAILED',
            'smime.USER_CERT_EXPIRED',
            'smime.USER_CERT_REVOKED',
            'smime.USER_CERT_EMAIL_ADDRESS_NOT_MATCHING',
            'smime.USER_CERT_NOT_TRUSTED',
            'smime.RECIPIENT_SMIME_CERT_NOT_FOUND'
        ];
        //if one of the certificate error occurs, prepend 'Message Signing Failed' or 'Message Encryption Failed' message as well.
        if (certErrorCodes.indexOf(errorCode) > -1) {
            var encrypt = this._shouldEncrypt();
            if (encrypt) {
                ZMsg[errorCode] = ZMsg['smime.ENCRYPTION_FAILED'] + " " + com_zimbra_securemail[errorCode];
            } else {
                ZMsg[errorCode] = ZMsg['smime.SIGNING_FAILED'] + " " + com_zimbra_securemail[errorCode];
            }
            //if we get 'smime.RECIPIENT_SMIME_CERT_NOT_FOUND' error, need to show email addresses as well whose certificate is missing
            if (errorCode == 'smime.RECIPIENT_SMIME_CERT_NOT_FOUND') {
                ZMsg[errorCode] = AjxMessageFormat.format(ZMsg[errorCode], [ex.msg])
            }
            //handle new window case
            if (appCtxt.isChildWindow) {
                ex.getErrorMsg = function() {
                    return ex.message;
                };
                ex.message = ZMsg[errorCode];
                ex.msg = ZMsg[errorCode];
            }
        }
        //Handle UNKNOWN_DOCUMENT error
        if(errorCode == ZmCsfeException.SVC_UNKNOWN_DOCUMENT) {
            ex.getErrorMsg = function() {
                return com_zimbra_securemail['smime.SERVER_EXTENSION_NOT_INSTALLED'];
            };
        }
    }
};

/**
 * Callback function which will run when Preference module is loaded
 * @private
 */
ZmSecureMail.prototype._handlePreferencesLoad = function() {
    ZmSecureMailPreferences.init(this);
};

/**
 * Workaround for lazy loading of Zimlet file
 * @private
 */
ZmSecureMail.prototype._handleLazyLoad = function() {
    var currentAppName = appCtxt.getCurrentAppName();
    if (currentAppName === ZmApp.MAIL) {
        this._handleLazyLoadMail();
    } else if (currentAppName === ZmApp.CONTACTS) {
        this._handleLazyLoadContact();
    }
};

/**
 * Workaround for lazy loading of Zimlet file for Mail App
 * @private
 */
ZmSecureMail.prototype._handleLazyLoadMail = function() {
    var currentView = appCtxt.getCurrentView();
    var controller = appCtxt.getCurrentController();
    var mailItem = controller && controller.getMsg && controller.getMsg();
    if (!mailItem) {
        //no mail is selected
        return;
    }
    if (currentView instanceof ZmMailMsgView) {
        //Reading Pan OFF: mail opened in separate tab
        this.onMsgView(mailItem, null, currentView);
    } else if (currentView instanceof ZmConvView2) {
        //Reading Pan OFF: conversation opened in separate pan
        AjxUtil.foreach(currentView._msgViews, function(capsuleView) {
            this.onMsgView(mailItem, null, capsuleView);
        }.bind(this));
    } else if (currentView instanceof ZmTradView) {
        //Reading Pan On: Message View
        var msgView = currentView.getMsgView();
        this.onMsgView(mailItem, null, msgView);
    } else if (currentView instanceof ZmConvDoublePaneView) {
        //Reading Pan On: Conversation view
        var msgView = currentView.getMsgView();
        AjxUtil.foreach(msgView._msgViews, function(capsuleView) {
            this.onMsgView(mailItem, null, capsuleView);
        }.bind(this));
    }
};

/**
 * Workaround for lazy loading of Zimlet file for Contact App
 * @private
 */
ZmSecureMail.prototype._handleLazyLoadContact = function() {
    var currentView = appCtxt.getCurrentView();
    var controller = appCtxt.getCurrentController();
    if (!currentView._contact) {
        return;
    }
    var contact = currentView._contact;
    if (contact.certificate) {
        //if certificate present in contact object, remove userCertificate custom attribute and add contact update event handler
        contact.removeAttr('userCertificate');
        contact.addChangeListener(new AjxListener(this, this._onContactUpdate));
    }
    if (currentView instanceof ZmContactSplitView) {
        //contact view
        //if certificate present in contact object re-render view
        if (contact.certificate) {
            currentView.setContact(contact, controller.isGalSearch());
        }
        this.onContactView(contact);
    } else if (currentView instanceof ZmEditContactView) {
        //contact edit view
        //if certificate present in contact object re-render view
        if (contact.certificate) {
            currentView.set(contact);
        }
        this.onContactEdit(currentView, contact);
    }
};

/**
 * Hides remove attachment links for Signed or Encrypted message
 * @param msg
 * @param msgView
 * @private
 */
ZmSecureMail.prototype._hideRemoveAttachmentLinks = function(msg, msgView) {
    //if message is not encrypted return
    if (msg && !msg.isEncrypted) {
        return;
    }
    //hides 'Remove All' attachment link
    var removeAllAttachmentElement = Dwt.byId(msgView._viewId + "_removeAll");
    if (removeAllAttachmentElement) {
        var tr = this.closest(removeAllAttachmentElement, 'tr');
        tr && (tr.outerHTML = "");
    }
    //hide 'Remove' attachment link for each attachment
    var removeAttachmentLinks = document.querySelectorAll('[id^="' + msgView._attLinksId + '_"][id$="_' + ZmMailMsgView.ATT_LINK_REMOVE + '"]');
    AjxUtil.foreach(removeAttachmentLinks, function(el) {
        if (el.previousSibling && el.previousSibling.nodeType === 3) {
            //if previous sibling is Text node i.e. separator " | "
            el.previousSibling.nodeValue.indexOf("|") > -1 && (el.previousSibling.nodeValue = "");
        }
        el.outerHTML = "";
    });
};

/**
 * DOM Utility method to get closest ancestor of the current element (or the current element itself) which matches the selectors given in parameter
 * Inspired from https://developer.mozilla.org/en-US/docs/Web/API/Element/closest
 * @param el
 * @param selector
 * @returns {*}
 */
ZmSecureMail.prototype.closest = function(el, selector) {
    var matchesFn = 'matches';

    // check for vendor prefix
    ['matches', 'webkitMatchesSelector', 'mozMatchesSelector', 'msMatchesSelector', 'oMatchesSelector'].some(function(fn) {
        if (typeof document.body[fn] == 'function') {
            matchesFn = fn;
            return true;
        }
        return false;
    });

    var parent;

    // traverse parents
    while (el) {
        parent = el.parentElement;
        if (parent && parent[matchesFn](selector)) {
            return parent;
        }
        el = parent;
    }

    return null;
};
