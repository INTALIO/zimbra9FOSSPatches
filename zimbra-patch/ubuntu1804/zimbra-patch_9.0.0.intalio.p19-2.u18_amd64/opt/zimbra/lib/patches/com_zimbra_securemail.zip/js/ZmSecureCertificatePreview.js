/**
 * ZmSecureCertificatePreview Class
 * @class
 *
 * This class represents certificate preview row, once the certificate is uploaded
 *
 * @param params
 * @constructor
 */

ZmSecureCertificatePreview = function(params) {
    if (!params && !params.certificates) {
        return;
    }
    DwtComposite.call(this, params);
    this._init(params);
};

ZmSecureCertificatePreview.prototype = new DwtComposite();

ZmSecureCertificatePreview.prototype.constructor = ZmSecureCertificatePreview;

/**
 * Initializes params and render certificate rows
 * @param params
 * @private
 */
ZmSecureCertificatePreview.prototype._init = function(params) {
    this.htmlId = this.getHTMLElId();
    this.parent = params.parent || null; //parent
    this.certificates = params.certificates || []; //certificates
    //view certificate handler
    this.viewCertificateHandler = params.viewCertificateHandler || ZmCertificateView._showCertificate;
    //remove certificate handler
    this.removeCertificateHandler = params.removeCertificateHandler || null;
    //whether this certificate is being rendered on MailMsg item
    this.type = params.type && params.type.toUpperCase() || "PREF"; //PREF, MSG, CONTACT_VIEW, CONTACT_EDIT
    //isSigned
    this.isSigned = params.isSigned || false;
    //isEncrypted
    this.isEncrypted = params.isEncrypted || false;
    //render all certificates
    if(this.certificates.length == 0 && (!this.isSigned && this.isEncrypted)) {
        //encrypted only case, no certificate will be there for this case
        this._renderEncryptionLabel();
    } else {
        AjxUtil.foreach(this.certificates, function(crt) {
            this._render(crt);
        }.bind(this));
    }
};

/**
 * Render's certificate row for each certificate
 * @param certificate
 * @private
 */
ZmSecureCertificatePreview.prototype._render = function(certificate) {
    //TODO: Append in case of multiple certificates
    this.parent._createHtmlFromTemplate('ZmSecureMail#CertificateSummary', {id: this.htmlId});
    this._renderCertificateErrorLabel(certificate);
    this._renderUserLabel(certificate);
    this._renderRemoveLabel(certificate);
    this._renderViewLabel(certificate);
};

/**
 * Handles and shows any error in certificate
 * @param certificate
 * @private
 */
ZmSecureCertificatePreview.prototype._renderCertificateErrorLabel = function(certificate) {
    if (!certificate.errorCode) {
        var certStatusLabelNode = Dwt.byId(this.htmlId + '_certStatusLabel');
        certStatusLabelNode ? certStatusLabelNode.outerHTML = "" : null;
        return;
    }
    var certStatusLabel = new DwtLabel({parent: this.parent, style: DwtLabel.IMAGE_LEFT});
    certStatusLabel.reparentHtmlElement(this.htmlId + "_certStatusLabel");
    certStatusLabel.setImage('Invalid');
    //check for error codes
    switch (certificate.errorCode) {
        case 'SIGNER_DIGEST_MISMATCH':
            certStatusLabel.setText(com_zimbra_securemail.tamperedMsg);
            break;
        case 'CERTIFICATE_NOT_YET_VALID':
            certStatusLabel.setText(com_zimbra_securemail.notYetValidCertificateMsg);
            break;
        case 'CERTIFICATE_REVOKED':
            certStatusLabel.setText(com_zimbra_securemail.revokedCertificateMsg);
            break;
        case 'CERTIFICATE_NOT_TRUSTED':
            certStatusLabel.setText(com_zimbra_securemail.untrustedCertificateMsg);
            break;
        case 'CERTIFICATE_EMAIL_ADDRESS_NOT_MATCHING':
            certStatusLabel.setText(com_zimbra_securemail.certificateEmailInvalidMsg);
            break;
        case 'INVALID_SIGNATURE':
            certStatusLabel.setText(com_zimbra_securemail.invalidSignatureMsg);
            break;
        case 'SIGNATURE_VALIDATION_FAILED':
            certStatusLabel.setText(com_zimbra_securemail.signatureValidationFailedMsg);
            break;
        case 'CERTIFICATE_VALIDATION_FAILED':
        case 'VERIFIER_CERTIFICATE_NOT_VALID':
            certStatusLabel.setText(com_zimbra_securemail.invalidCertificateMsg);
            break;
        case 'CERTIFICATE_EXPIRED':
        case 'VERIFIER_NOT_VALID_AT_SIGNING_TIME':
            certStatusLabel.setText(com_zimbra_securemail.expiredCertificateMsg);
            break;
        default:
            certStatusLabel.setText(certificate.errorCode);

    }
};

/**
 * Handles and shows the certificate owner
 * @param certificate
 * @private
 */
ZmSecureCertificatePreview.prototype._renderUserLabel = function(certificate) {
    var userLabel = new DwtLabel({parent: this.parent, style: DwtLabel.IMAGE_LEFT});
    userLabel.reparentHtmlElement(this.htmlId + "_userLabel");
    if (['MSG', 'CONTACT_VIEW', 'CONTACT_EDIT'].indexOf(this.type) > -1) {
        var userText = certificate.emailAddress;
    } else {
        if (certificate.issuedTo && certificate.issuedTo.cn) {
            var userText = certificate.issuedTo.cn + " &#60;" + certificate.emailAddress + "&#62;";
        } else {
            var userText = certificate.emailAddress;
        }
    }
    if (this.isSigned && this.isEncrypted) {
        userText = com_zimbra_securemail.signedAndencryptedMsg + "&nbsp;" + userText;
    } else if (this.isSigned) {
        userText = com_zimbra_securemail.signedMsg + "&nbsp;" + userText;
    }
    userLabel.setText(userText);
    if (!certificate.errorCode) {
        this.isEncrypted ? userLabel.setImage('SignEncrypt') : userLabel.setImage('Valid');
    }
    //if email address is missing..remove html
    if (!userText) {
        userLabel = Dwt.byId(this.htmlId + '_userLabel');
        userLabel ? userLabel.outerHTML = "" : null;
    }
};

/**
 * Handles and shows the certificate remove label
 * @param certificate
 * @private
 */
ZmSecureCertificatePreview.prototype._renderRemoveLabel = function(certificate) {
    //in case of CONTACT_VIEW and MSG, don't show remove label
    if (['CONTACT_VIEW', 'MSG'].indexOf(this.type) > -1) {
        var removeLabel = Dwt.byId(this.htmlId + '_removeLabel');
        removeLabel ? removeLabel.outerHTML = "" : null;
        return;
    }
    var removeLabel = new DwtLabel({parent: this.parent});
    removeLabel.setText(com_zimbra_securemail.certificateRemoveLabel);
    removeLabel.reparentHtmlElement(this.htmlId + "_removeLabel");
    removeLabel.setClassName("FakeAnchor");
    removeLabel.setHandler(DwtEvent.ONCLICK, AjxCallback.simpleClosure(this.removeCertificateHandler, this, certificate));
};

/**
 * Handles and shows view certificate label
 * @param certificate
 * @private
 */
ZmSecureCertificatePreview.prototype._renderViewLabel = function(certificate) {
    var viewLabel = new DwtLabel({parent: this.parent});
    if (['PREF'].indexOf(this.type) > -1) {
        viewLabel.setText(com_zimbra_securemail.certificateViewLabel);
    } else {
        viewLabel.setText(com_zimbra_securemail.certificateViewFullLabel);
    }
    viewLabel.reparentHtmlElement(this.htmlId + "_viewLabel");
    viewLabel.setClassName("FakeAnchor");
    viewLabel.setHandler(DwtEvent.ONCLICK, AjxCallback.simpleClosure(this.viewCertificateHandler, this, certificate));
};

/**
 * Render encryption only message
 * @private
 */
ZmSecureCertificatePreview.prototype._renderEncryptionLabel = function() {
    var userLabel = new DwtLabel({parent: this.parent, style: DwtLabel.IMAGE_LEFT});
    userLabel.reparentHtmlElement(this.htmlId + "_userLabel");
    userLabel.setText(com_zimbra_securemail.encryptedMsg);
    userLabel.setImage('Encrypt');
};

