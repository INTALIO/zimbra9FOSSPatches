/**
 * Creates a certificate password dialog.
 * @class
 * This class represents a certificate password dialog.
 * @param {Hash}    params        a hash of parameters
 * @param    {DwtControl}    params.parent         the parent
 * @param    {AjxCallback}    params.okCallback        the Ok button callback
 * @param    {AjxCallback}    params.cancelCallback    the cancel button callback
 *
 * @extends        ZmDialog
 */
ZmCertificatePasswordDialog = function(params) {

    if (!params) {
        return;
    }

    ZmDialog.call(this, {
        parent: params.parent,
        className: "ZmCertificatePasswordDialog",
        title: this.getLabel("passwordDialogTitle"),
        id: "CertificatePasswordDialog",
        disposeOnPopDown : true //dispose dialog on popdown
    });
    this._okCallback = params.okCallback;
    this._cancelCallback = params.cancelCallback;
    this._session = params.session || {};

    //setting password field in this._nameField variable.
    this._setNameField(this._nameFieldId);
    this.setSize(400, 150);
    this._createControls();
};

ZmCertificatePasswordDialog.prototype = new ZmDialog;
ZmCertificatePasswordDialog.prototype.constructor = ZmCertificatePasswordDialog;

ZmCertificatePasswordDialog.prototype.toString = function() {
    return "ZmCertificatePasswordDialog";
};

/**
 * Pops up the dialog.
 * @param withError
 */
ZmCertificatePasswordDialog.prototype.popup = function(withError) {
    ZmDialog.prototype.popup.call(this);
    withError ? this.setErrorMsg() : this.resetErrorMsg();
    this.reset();
    this._toggleOKButton(false);
};

ZmCertificatePasswordDialog.prototype.getLabel = function(key) {
    return com_zimbra_securemail[key];
};


ZmCertificatePasswordDialog.prototype.setErrorMsg = function() {
    this.reset();
    this._toggleOKButton(false);
    if (this._errorEl) {
        this._errorEl.innerHTML = this.getLabel("passwordDialogError");
    }
};

ZmCertificatePasswordDialog.prototype.resetErrorMsg = function() {
    if (this._errorEl) {
        this._errorEl.innerHTML = "";
    }
};

ZmCertificatePasswordDialog.prototype._createControls = function() {
    this._toggleOKButton(false);
    var cancelBtn = this.getButton(DwtDialog.CANCEL_BUTTON);
    cancelBtn.setText(this.getLabel("passwordDialogCancel"));
    this.setButtonListener(DwtDialog.CANCEL_BUTTON, new AjxListener(this, this._cancelButtonListener));

    var okBtn = this.getButton(DwtDialog.OK_BUTTON);
    okBtn.setText(this.getLabel("passwordDialogSubmit"));
    Dwt.setHandler(this._nameField, DwtEvent.ONKEYUP, this._handleKeyUp.bind(this));
};


/**
 * Submit button listener.
 * Call's the okCallback if exists with input password value.
 * @param ev
 * @private
 */
ZmCertificatePasswordDialog.prototype._okButtonListener = function(ev) {
    this._session.password = this._nameField.value;
    this._okCallback && this._okCallback.run(this._session);
};

/**
 * Cancel button listener.
 * Call's the cancelCallback if exists.
 * @param ev
 * @private
 */
ZmCertificatePasswordDialog.prototype._cancelButtonListener = function(ev) {
    this._cancelCallback && this._cancelCallback.run();
    this.popdown();
};

/**
 * Enter button handler
 * @param ev
 * @private
 */
ZmCertificatePasswordDialog.prototype._enterListener = function(ev) {
    var pwd = this._nameField.value;
    if (pwd && pwd.length > 0) {
        this._okButtonListener();
    }
};

/**
 * Keyup event handler for password field.
 * Enables/Disables the OK button based on input field value.
 * @param ev
 * @private
 */
ZmCertificatePasswordDialog.prototype._handleKeyUp = function(ev) {
    var key = DwtKeyEvent.getCharCode(ev);
    if (key === DwtKeyEvent.KEY_TAB) {
        return;
    }
    var el = DwtUiEvent.getTarget(ev);
    var val = el && el.value;
    this._toggleOKButton(val.length > 0);
};

/**
 * Toggles Submit button visibility
 * @param enable
 * @private
 */
ZmCertificatePasswordDialog.prototype._toggleOKButton = function(enable) {
    var okBtn = this.getButton(DwtDialog.OK_BUTTON);
    okBtn.setEnabled(enable);
};

/* Overriding DwtDialog functions. */

/**
 *
 * @returns {string} starter string for buttons container
 * @private
 */
ZmCertificatePasswordDialog.prototype._getButtonsContainerStartTemplate = function() {
    return "<table role='presentation' class='ZmCertificateDialogButtonsContainer'><tr>";
};

ZmCertificatePasswordDialog.prototype._contentHtml = function() {
    this._nameFieldId = this._htmlElId + "_password";
    var data = {
        id: this._htmlElId,
        labelPasswd: this.getLabel("passwordDialogInputLabel")
    };
    return AjxTemplate.expand("ZmSecureMail#ZmCertificatePasswordDialog", data);
};

/**
 *
 * @param templateId
 * @param data
 * @private
 */
ZmCertificatePasswordDialog.prototype._createHtmlFromTemplate = function(templateId, data) {
    DwtBaseDialog.prototype._createHtmlFromTemplate.call(this, templateId, data);

    var focusId = data.id + "_focus";
    if (document.getElementById(focusId)) {
        this._focusElementId = focusId;
    }
    this._buttonsEl = document.getElementById(data.id + "_buttons");
    if (this._buttonsEl) {
        var html = ["<span id='certificatePasswordError'>", "</span>"];
        var idx = 2;
        this._addButtonsHtml(html, idx);
        this._buttonsEl.innerHTML = html.join("");
        this._errorEl = document.getElementById('certificatePasswordError');
    }
};