/*
 * ***** BEGIN LICENSE BLOCK *****
 * Zimbra Collaboration Suite, Network Edition.
 * Copyright (C) 2012, 2013, 2014, 2016 Synacor, Inc.  All Rights Reserved.
 * ***** END LICENSE BLOCK *****
 * @Author Raja Rao DV
 * 
 */

/**
 * @class This class represents the Click2Call zimlet.
 *
 * @extends ZmZimletBase
 */

// todo - this zimlet is named incorrectly
//
// This zimlet contains vendor-specific code for a UC (Unified communication) provider
// In this case - Mitel
// Better name would be something like UC_Mitel


ZmClick2CallZimlet = function() {
	//do nothing;
};

ZmClick2CallZimlet.prototype = new ZmZimletBase();
ZmClick2CallZimlet.prototype.constructor = ZmClick2CallZimlet;

ZmClick2CallZimlet.OP_CLICK_2_CALL_ZIMLET_VOICE_PIN = "CLICK_2_CALL_ZIMLET_VOICE_PIN";

ZmClick2CallZimlet.prototype.init = function() {
    //Return if unauthorized to use UC feature
    if (!appCtxt.getSettings()._hasVoiceFeature()) {
        return;
    }
    if (this.initialized) return;

	ZmZimletBase.prototype.init.apply(this, arguments);

    var voiceApp = appCtxt.getApp(ZmApp.VOICE);
    if (!voiceApp){
        this.initialized = true;
        return;
    }
    voiceApp.registerUCProvider(this);    // Register as a UC provider with the the voice app

	//todo - remove this when we get server-support for single-signon
    /*
	this.toPhoneNumber = "16504274506";

	this.email = "raja";
	this.password = "password";
	this.mailbox_id = "1010";
	this.voice_pin = "1234";
    */

    //this.server = this.getConfig("click2call_server");
    // debugger;
    var soapDoc = AjxSoapDoc.create("GetUCInfoRequest", "urn:zimbraVoice");
    var respCallback = new AjxCallback(this, this._handleResponseUCInfo, [true]);
    var respErrorCallback = new AjxCallback(this, this._handleErrorResponseUCInfo, [true]); 
    var params = {
        soapDoc: soapDoc,
        asyncMode: true,
        noBusyOverlay: true,
        callback: respCallback,
        errorCallback: respErrorCallback
    };
    appCtxt.getAppController().sendRequest(params);

    this.initialized = true;
};


//  The UCInfo request returns the logged in user's Mitel id, password and also the base SOAP url for call control

ZmClick2CallZimlet.prototype._handleResponseUCInfo = function(onInit, result) {
    var response = result.getResponse();
    if (response.GetUCInfoResponse) {
        var attrs = response.GetUCInfoResponse.attrs && response.GetUCInfoResponse.attrs[0] && response.GetUCInfoResponse.attrs[0]._attrs;
        if (attrs) {
            this.username = attrs.zimbraUCUsername;
            this.password = attrs.zimbraUCPassword;
            this.serverUrl = attrs.zimbraUCCallControlURL;   // Base url
        }
        this._getVoiceInfo(onInit);
        this._isLoaded = true;
    }
    this.soapAPI = new ZmClick2CallProviderAPIs(this, this.serverUrl, this.username, this.password)
};

ZmClick2CallZimlet.prototype._handleErrorResponseUCInfo = function(result, onInit) {
    // todo - fix for proper error handling
};

ZmClick2CallZimlet.prototype._getVoiceInfo =
    function(onInit) {
        var soapDoc = AjxSoapDoc.create("GetVoiceInfoRequest", "urn:zimbraVoice");
        var respCallback = new AjxCallback(this, this._handleResponseVoiceInfo, [onInit]);
        var respErrorCallback = new AjxCallback(this, this._handleErrorResponseVoiceInfo, [onInit]);
        var params = {
            soapDoc: soapDoc,
            asyncMode: true,
            noBusyOverlay: true,
            callback: respCallback,
            errorCallback: respErrorCallback
        };
        appCtxt.getAppController().sendRequest(params);
        this._gettingVoiceInfo = true;

    };
ZmClick2CallZimlet.prototype._handleResponseVoiceInfo = function(onInit, result) {
    //debugger;
    var response = result.getResponse();
    if (response.GetVoiceInfoResponse && response.GetVoiceInfoResponse.storeprincipal) {
        this.contactId=response.GetVoiceInfoResponse.storeprincipal[0] && response.GetVoiceInfoResponse.storeprincipal[0].id;
        this._getPresence()
        this._isLoaded = true;
    }
};

ZmClick2CallZimlet.prototype._handleErrorResponseVoiceInfo = function(onInit, result) {
    var voiceApp = appCtxt.getApp(ZmApp.VOICE);
    if (!voiceApp){
        return;
    }
	if (!onInit) {
		//don't display error if this is on initialization
    	voiceApp.processErrors(result);
	}
    return true;
};

ZmClick2CallZimlet.prototype._getPresence =
    function() {

           // TODO - fix when we can get presence from Mitel
           return;  // Dummy out presence for now

           var p = this.soapAPI.getPresence(this.contactId, new AjxCallback(this,
               this._handleResponsePresence));
    };
ZmClick2CallZimlet.prototype._handleResponsePresence = function(result) {
    var response = result;
};

// todo - Parsing error strings for Mitel, need a better way

ZmClick2CallZimlet.prototype.getErrorDescription = function(ex) {
    var errorMessage = ZmMsg.voicemailErrorUnknown;
    if (!ex.code){
        return errorMessage;
    }
    if (ex.code.indexOf("mitel") != -1){
        msg = ex.msg || "";
        if (msg.indexOf("401") != -1){
            errorMessage = ZmMsg.voicemailErrorAuthFailure;  // Not authorized
        }
        else if (msg.indexOf("0009") != -1){
            errorMessage = ZmMsg.voicemailErrorPIN;   // Invalid PIN
        }
        else if (msg.toLowerCase().indexOf("null") != -1){
            errorMessage = ZmMsg.voicemailErrorPIN;   // Null PIN
        }
		else if (ex.code == "mitel.INVALID_PIN") {
			errorMessage = ZmMsg.voicemailErrorPIN;
		}
    }
	else if (ex.code == ZmVoiceApp.ERROR_CODE_AUTH) {
		errorMessage = ZmMsg.voicemailErrorAuthFailure;
	};
	
    return errorMessage;
};

// Mitel has a voice pin

ZmClick2CallZimlet.prototype.hasVoicePIN = function() {
    return true;
};


ZmClick2CallZimlet.prototype.initializeToolbar = function(app, toolbar, controller, viewId) {
    /*
     *  Dummy out the "Voice Pin" button in the Voice mail toolbar
     *
	if(viewId == ZmId.VIEW_VOICEMAIL && !toolbar.getOp(ZmClick2CallZimlet.OP_CLICK_2_CALL_ZIMLET_VOICE_PIN)) {
		var buttonArgs = {
			text	: this.getMessage("voicePIN"),
			tooltip: this.getMessage("voicePINTooltip"),
			index: toolbar.opList.length,
			image: "Telephone"
		};
		var button = toolbar.createOp(ZmClick2CallZimlet.OP_CLICK_2_CALL_ZIMLET_VOICE_PIN, buttonArgs, true, true);
		if(controller.operationsToEnableOnZeroSelection && controller.operationsToEnableOnMultiSelection) {
			controller.operationsToEnableOnZeroSelection.push(ZmClick2CallZimlet.OP_CLICK_2_CALL_ZIMLET_VOICE_PIN);
			controller.operationsToEnableOnMultiSelection.push(ZmClick2CallZimlet.OP_CLICK_2_CALL_ZIMLET_VOICE_PIN);
		}
		button.addSelectionListener(new AjxListener(this, this._changeVoicePinListener, [controller]));
	}
	*/
};

ZmClick2CallZimlet.prototype.getPresence =
    function() {

    };

ZmClick2CallZimlet.prototype._changeVoicePinListener = function() {
	if(!this._voicePINDlg) {
		this._voicePINDlg = new ZmClick2CallVoicePINDlg(this);
	}
	this._voicePINDlg.popup();
};

ZmClick2CallZimlet.prototype.toolTipPoppedUp = function(spanElement, contentObjText, matchContext, canvas) {
	var subs = {contentObjText: contentObjText, phoneStr: ZmMsg.phone};
	canvas.innerHTML = AjxTemplate.expand("com_zimbra_click2call_mitel.templates.ZmClick2Call#Tooltip", subs);
};

ZmClick2CallZimlet.prototype.clicked = function(myElement, toPhoneNumber) {
	this.toPhoneNumber = toPhoneNumber;
	this._showFromPhoneDlg();
};

ZmClick2CallZimlet.prototype.display = function(toPhoneNumber) {
	this.toPhoneNumber = toPhoneNumber;
	this._showFromPhoneDlg();
};


ZmClick2CallZimlet.prototype._showFromPhoneDlg = function() {
	if (!this.zmFromPhoneDlg) {
		this.zmFromPhoneDlg = new ZmClick2CallFromPhoneDlg(this.getShell(), this,
				this._destinationsInZimbra);
	}
	this.zmFromPhoneDlg.toPhoneNumber = this.toPhoneNumber;
	this.zmFromPhoneDlg.showDialog();
};

/**
 * This method adds the Click2Call icon to the extensible contact card
 */
ZmClick2CallZimlet.prototype.onEmailHoverOver =
    function(emailZimlet) {
        emailZimlet.addSubscriberZimlet(this, false, {presenceCallback: this.getPresence.bind(this)});
        this.emailZimlet = emailZimlet;
        this._addSlide();
    };

/**
 * This method adds the Click2Call icon to the extensible contact card
 */
ZmClick2CallZimlet.prototype.onPhoneClicked =
    function(phone) {
        if (!this.zmFromPhoneDlg) {
            this.zmFromPhoneDlg = new ZmClick2CallFromPhoneDlg(this.getShell(), this,
                this._destinationsInZimbra);
        }
        this.zmFromPhoneDlg.toPhoneNumber = this.toPhoneNumber = phone;
        this.zmFromPhoneDlg.showDialog();
    };

ZmClick2CallZimlet.prototype.getEmailZimlet =
    function(){
        return this.emailZimlet;
    }

ZmClick2CallZimlet.prototype._addSlide =
    function() {
        //Do not show "Call" slide if unauthorized to use UC feature
        if (!appCtxt.getSettings()._hasVoiceFeature()) {
            return;
        }
        var tthtml = this._getTooltipBGHtml();
        var selectCallback =  new AjxCallback(this, this._handleSlideSelect);

        this._slide = new EmailToolTipSlide(tthtml, true, "Click2CallZimletIcon", selectCallback, "Click to call");
        this.emailZimlet.slideShow.addSlide(this._slide);
    };

ZmClick2CallZimlet.prototype._handleSlideSelect =
    function() {
        if(this._slide.loaded) {
            return;
        }

        //this.emailZimlet.tooltip._poppedUp = true;  // Make tooltip unsticky so it can be closed
        this.emailZimlet.tooltip.setSticky(false);
        this.emailZimlet.popdown();
        this._setDefaultPhoneNumber();
        this._showFromPhoneDlg();

        if(this._slide) {
            this._slide.loaded = true;
        }
    };

ZmClick2CallZimlet.prototype._setDefaultPhoneNumber =
function () {
    this.toPhoneNumber = "";

    if (!this.emailZimlet)
        return;

    var data = this.emailZimlet._subscriberZimlets;
    if (!AjxUtil.isArray(data) || AjxUtil.isEmpty(data)) {
        return
    }

    var foundLatestData = false;
    var i = data.length - 1
    for (; i >= 0; i--) {
        if (AjxUtil.isInstance(data[i], UnknownPersonSlide)) {
            foundLatestData = true;
            break;
        }
    }

    if (!foundLatestData) {
        return;
    }

    this.toPhoneNumber = this._getContactPhoneNumber(data[i].attribs);
}

ZmClick2CallZimlet.prototype._getContactPhoneNumber =
function(attr) {
    if (!ZmEditContactView || !ZmEditContactView.prototype ||
        !ZmEditContactView.prototype.getPhoneOptions) {
        return "";
    }

    var phonePrefix = ZmEditContactView.prototype.getPhoneOptions.call(this);

    if (!AjxUtil.isArray(phonePrefix) || AjxUtil.isEmpty(phonePrefix)) {
        return "";
    }

    if (!attr) {
        return "";
    }

    for (var key in attr) {
        if (!key) {
            continue;
        }
        for (var i = 0; i < phonePrefix.length; i++) {
            if (phonePrefix[i].value.indexOf("Phone") >= 0
                && key.indexOf (phonePrefix[i].value) >= 0
                && !AjxUtil.isEmpty(attr[key])) {
                return attr[key];
            }
        }
    }
    return "";
}

ZmClick2CallZimlet.prototype._getTooltipBGHtml =
    function() {
        return AjxTemplate.expand("com_zimbra_click2call_mitel.templates.ZmClick2Call#Frame");
    };

// Replicating fix for bug 73264 from com_zimbra_phone

ZmClick2CallZimlet.prototype.match = function(line, startIndex) {
    //Does not match anything if unauthorized to use UC feature
    if (!appCtxt.getSettings()._hasVoiceFeature()) {
        return;
    }
    var re = this.RE;
    re.lastIndex = startIndex;
    var m = re.exec(line);
    if (!m) { return m; }

    var phone = m[0];
    // bug 73264, don't identify long digit sequence (length > 10) without separators as phone number
    if (phone.length > 10 &&
        phone[0] != "+"   &&
        !(AjxUtil.arrayContains(phone, " ")) &&
        !(AjxUtil.arrayContains(phone, ".")) &&
        !(AjxUtil.arrayContains(phone, "-"))) {
        return null;
    } else {
        m[0] = phone;
        return m;
    }
}

ZmClick2CallZimlet.prototype.disableUnreadOp = function() {
	return true;
};
