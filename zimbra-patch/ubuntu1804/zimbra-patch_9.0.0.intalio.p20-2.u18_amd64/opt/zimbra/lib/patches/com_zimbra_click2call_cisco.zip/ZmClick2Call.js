/*
 * ***** BEGIN LICENSE BLOCK *****
 * Zimbra Collaboration Suite, Network Edition.
 * Copyright (C) 2012, 2013, 2014, 2016 Synacor, Inc.  All Rights Reserved.
 * ***** END LICENSE BLOCK *****
 * @Author Raja Rao DV
 * 
 */

/**
 * @class This class represents the Click2Call zimlet.
 *
 * @extends ZmZimletBase
 */
ZmClick2CallZimlet = function() {
	//do nothing
};
ZmClick2CallZimlet.prototype = new ZmZimletBase();
ZmClick2CallZimlet.prototype.constructor = ZmClick2CallZimlet;

ZmClick2CallZimlet.OP_CLICK_2_CALL_ZIMLET_VOICE_PIN = "CLICK_2_CALL_ZIMLET_VOICE_PIN";

ZmClick2CallZimlet.prototype.init = function() {
    //Return if unauthorized to use UC feature
    if (!appCtxt.getSettings()._hasVoiceFeature()) {
        return;
    }
    ZmZimletBase.prototype.init.apply(this, arguments);

    var voiceApp = appCtxt.getApp(ZmApp.VOICE);  // Register as a UC provider with the the voice app
    if (!voiceApp){
        return;
    }
    voiceApp.registerUCProvider(this);

    this.UC_INFO_LOADED = false;
    this.getUserUCInfo();
};

/**
 * Post callback after user logs in presence server
 * @param result
 */
ZmClick2CallZimlet.prototype._handleLoginResponse = function (result) {
     //alert(result.sessionKey);
}

/**
 * Post callback after get a contact's presence info
 * @param result
 */
ZmClick2CallZimlet.prototype._handlePresenceResponse = function (result) {
    alert(result.imStatus);
}

ZmClick2CallZimlet.prototype.getUserUCInfo = function () {
    var soapDoc = AjxSoapDoc.create("GetUCInfoRequest", "urn:zimbraVoice");
    var respCallback = new AjxCallback(this, this._handleUCInfoResponse);
    var respErrorCallback = new AjxCallback(this, this._handleErrorResponseUCInfo);
    var params = {
        soapDoc: soapDoc,
        asyncMode: true,
        noBusyOverlay: true,
        callback: respCallback,
        errorCallback: respErrorCallback
    };
    appCtxt.getAppController().sendRequest(params);
}

/*
 * Hand the response, check the completeness of uc info
 */
ZmClick2CallZimlet.prototype._handleUCInfoResponse = function(result) {
    result = result._data;
    if (!result || !result.GetUCInfoResponse) {
        this._popupErrorDlg(this.getMessage("err_failedFetchUCINfo"));
        return;
    }

    var data = result.GetUCInfoResponse;
    if (!data.attrs || !(data.attrs instanceof Array) || data.attrs.length < 1) {
        this._popupErrorDlg(this.getMessage("err_failedFetchUCINfo"));
        return;
    }
    var ucInfo = data.attrs[0]._attrs;
    this.username = ucInfo.zimbraUCUsername;
    this.password = ucInfo.zimbraUCPassword;
    this.serverUrl = ucInfo.zimbraUCCallControlURL;
    this.soapAPI = new ZmClick2CallProviderAPIs(this, this.serverUrl, this.username, this.password)

    this._applicationSessionId = ucInfo.zimbraUCPresenceSessionId;
    this._ciscoUser = ucInfo.zimbraUCUsername;
    this.presenceServer = ucInfo.zimbraUCPresenceURL;
    this.presenceAPI = new ZmClick2CallPresenceAPIs(this, this._ciscoUser, this.presenceServer,
        this._applicationSessionId);

    var presenceLoginCallback = new AjxCallback(this, this._handleLoginResponse);
    this.presenceAPI.login(presenceLoginCallback);

    this.UC_INFO_LOADED = true;
};

ZmClick2CallZimlet.prototype._popupErrorDlg = function (msg, ex) {
    var errorDialog = appCtxt.getErrorDialog();
    errorDialog.reset();

    var details = (ex && ex.message) ? ex.message : ex;
    details = AjxUtil.isEmpty(details) ? "" : details;
    errorDialog.setMessage(msg, details, DwtMessageDialog.CRITICAL_STYLE, ZmMsg.zimbraTitle);
    errorDialog.popup();
}

/*ZmClick2CallZimlet.prototype._getVoiceInfo =
    function() {
        var soapDoc = AjxSoapDoc.create("GetVoiceInfoRequest", "urn:zimbraVoice");
        var respCallback = new AjxCallback(this, this._handleResponseVoiceInfo);
        var respErrorCallback = new AjxCallback(this, this._handleErrorResponseVoiceInfo);
        var params = {
            soapDoc: soapDoc,
            asyncMode: true,
            noBusyOverlay: true,
            callback: respCallback,
            errorCallback: respErrorCallback
        };
        appCtxt.getAppController().sendRequest(params);
        this._gettingVoiceInfo = true;

    };
ZmClick2CallZimlet.prototype._handleResponseVoiceInfo = function(result) {
    //debugger;
    var response = result.getResponse();
    if (response.GetVoiceInfoResponse && response.GetVoiceInfoResponse.storeprincipal) {
        this.contactId=response.GetVoiceInfoResponse.storeprincipal[0] && response.GetVoiceInfoResponse.storeprincipal[0].id;
        this._getPresence()
        this._isLoaded = true;
    }
}; */

ZmClick2CallZimlet.prototype._handleErrorResponseVoiceInfo = function(result) {
    var voiceApp = appCtxt.getApp(ZmApp.VOICE);
    if (!voiceApp){
        return;
    }
    voiceApp.processErrors(result);
    return true;
};

// Provide error specific to the UC Provider

ZmClick2CallZimlet.prototype.getErrorDescription = function(ex) {
	var errorMessage = ZmMsg.voicemailErrorUnknown;
	if (!ex.code){
		return errorMessage;
	}
	if (ex.code.indexOf("voice.UNABLE_TO_AUTH") !=-1) {
		errorMessage = ZmMsg.voicemailErrorAuthFailure;   // Not authorized
	}
	else if (ex.code.indexOf("cisco") != -1){
		msg = ex.msg || "";
		if (msg.toLowerCase().indexOf("unable to auth") != -1){
			errorMessage = ZmMsg.voicemailErrorAuthFailure;   // Not authorized
		}
	}

	return errorMessage;
};

// Cisco doesn't have a voice pin
ZmClick2CallZimlet.prototype.hasVoicePIN = function() {
    return false;
};

/*ZmClick2CallZimlet.prototype._getPresence =
    function() {

           // TODO - fix when we can get presence from Mitel
           return;  // Dummy out presence for now

           var p = this.soapAPI.getPresence(this.contactId, new AjxCallback(this,
               this._handleResponsePresence));
    };
ZmClick2CallZimlet.prototype._handleResponsePresence = function(result) {
    var response = result;
};*/


ZmClick2CallZimlet.prototype.initializeToolbar = function(app, toolbar, controller, viewId) {
    /*
     *  Dummy out the "Voice Pin" button in the Voice mail toolbar
     *
	if(viewId == ZmId.VIEW_VOICEMAIL && !toolbar.getOp(ZmClick2CallZimlet.OP_CLICK_2_CALL_ZIMLET_VOICE_PIN)) {
		var buttonArgs = {
			text	: this.getMessage("voicePIN"),
			tooltip: this.getMessage("voicePINTooltip"),
			index: toolbar.opList.length,
			image: "Telephone"
		};
		var button = toolbar.createOp(ZmClick2CallZimlet.OP_CLICK_2_CALL_ZIMLET_VOICE_PIN, buttonArgs, true, true);
		if(controller.operationsToEnableOnZeroSelection && controller.operationsToEnableOnMultiSelection) {
			controller.operationsToEnableOnZeroSelection.push(ZmClick2CallZimlet.OP_CLICK_2_CALL_ZIMLET_VOICE_PIN);
			controller.operationsToEnableOnMultiSelection.push(ZmClick2CallZimlet.OP_CLICK_2_CALL_ZIMLET_VOICE_PIN);
		}
		button.addSelectionListener(new AjxListener(this, this._changeVoicePinListener, [controller]));
	}
	*/
};

ZmClick2CallZimlet.prototype.getPresence =
    function(presentity, presenceCallback) {
        //debugger;
        if (!this.presenceAPI){
            return null;
        }
        this.presenceAPI.getPresence(presentity, presenceCallback);
    };

ZmClick2CallZimlet.prototype._changeVoicePinListener = function() {
	if(!this._voicePINDlg) {
		this._voicePINDlg = new ZmClick2CallVoicePINDlg(this);
	}
	this._voicePINDlg.popup();
};

ZmClick2CallZimlet.prototype.toolTipPoppedUp = function(spanElement, contentObjText, matchContext, canvas) {
	var subs = {contentObjText: contentObjText, phoneStr: ZmMsg.phone};
	canvas.innerHTML = AjxTemplate.expand("com_zimbra_click2call.templates.ZmClick2Call#Tooltip", subs);
};

ZmClick2CallZimlet.prototype.clicked = function(myElement, toPhoneNumber) {
	this.toPhoneNumber = toPhoneNumber;
	this._showFromPhoneDlg();

    //TODO: Will move this call to a proper place
    //var getPresenceCallback = new AjxCallback(this, this._handlePresenceResponse);
    //this.presenceAPI.getPresence("dfeng@ciscocups.eng.vmware.com", getPresenceCallback);
};

ZmClick2CallZimlet.prototype.display = function(toPhoneNumber) {
	this.toPhoneNumber = toPhoneNumber;
	this._showFromPhoneDlg();
};


ZmClick2CallZimlet.prototype._showFromPhoneDlg = function() {
    //
    // Load the uc info if it is not set
    // Doing so will give users a second try if the previous tries failed.
    //
    if (!this.UC_INFO_LOADED) {
        appCtxt.setStatusMsg(ZmMsg.loading);
        try {
            this.getUserUCInfo();
        } catch (ex) {
            this._popupErrorDlg(this.getMessage("err_invalidUCInfo"), ex);
            return;
        }
    }

	if (!this.zmFromPhoneDlg) {
		this.zmFromPhoneDlg = new ZmClick2CallFromPhoneDlg(this.getShell(), this);
	}
	this.zmFromPhoneDlg.toPhoneNumber = this.toPhoneNumber;
	this.zmFromPhoneDlg.showDialog();
};

/**
 * This method adds the Click2Call icon to the extensible contact card
 */
ZmClick2CallZimlet.prototype.onEmailHoverOver =
    function(emailZimlet) {
        emailZimlet.addSubscriberZimlet(this, false, {presenceCallback: this.getPresence.bind(this)});
        this.emailZimlet = emailZimlet;
        this._addSlide();
    };

/**
 * This method adds the Click2Call icon to the extensible contact card
 */
ZmClick2CallZimlet.prototype.onPhoneClicked =
    function(phone) {
        if (!this.zmFromPhoneDlg) {
            this.zmFromPhoneDlg = new ZmClick2CallFromPhoneDlg(this.getShell(), this,
                this._destinationsInZimbra);
        }
        this.zmFromPhoneDlg.toPhoneNumber = this.toPhoneNumber = phone;
        this.zmFromPhoneDlg.showDialog();
    };

ZmClick2CallZimlet.prototype.getEmailZimlet =
    function(){
        return this.emailZimlet;
    }

ZmClick2CallZimlet.prototype._addSlide =
    function() {
        //Do not show "Call" slide if unauthorized to use UC feature
        if (!appCtxt.getSettings()._hasVoiceFeature()) {
            return;
        }
        var tthtml = this._getTooltipBGHtml();
        var selectCallback =  new AjxCallback(this, this._handleSlideSelect);

        this._slide = new EmailToolTipSlide(tthtml, true, "Click2CallZimletIcon", selectCallback, "Click to call");
        this.emailZimlet.slideShow.addSlide(this._slide);
    };

ZmClick2CallZimlet.prototype._handleSlideSelect =
    function() {
        if(this._slide.loaded) {
            return;
        }

        //this.emailZimlet.tooltip._poppedUp = true;  // Make tooltip unsticky so it can be closed
        this.emailZimlet.tooltip.setSticky(false);
        this.emailZimlet.popdown();
        this._setDefaultPhoneNumber();
        this._showFromPhoneDlg();

        if(this._slide) {
            this._slide.loaded = true;
        }
    };

ZmClick2CallZimlet.prototype._setDefaultPhoneNumber =
function () {
    this.toPhoneNumber = "";

    if (!this.emailZimlet)
        return;

    var data = this.emailZimlet._subscriberZimlets;
    if (!AjxUtil.isArray(data) || AjxUtil.isEmpty(data)) {
        return
    }

    var foundLatestData = false;
    var i = data.length - 1
    for (; i >= 0; i--) {
        if (AjxUtil.isInstance(data[i], UnknownPersonSlide)) {
            foundLatestData = true;
            break;
        }
    }

    if (!foundLatestData) {
        return;
    }

    this.toPhoneNumber = this._getContactPhoneNumber(data[i].attribs);
}

ZmClick2CallZimlet.prototype._getContactPhoneNumber =
function(attr) {
    if (!ZmEditContactView || !ZmEditContactView.prototype ||
        !ZmEditContactView.prototype.getPhoneOptions) {
        return "";
    }

    var phonePrefix = ZmEditContactView.prototype.getPhoneOptions.call(this);

    if (!AjxUtil.isArray(phonePrefix) || AjxUtil.isEmpty(phonePrefix)) {
        return "";
    }

    if (!attr) {
        return "";
    }

    for (var key in attr) {
        if (!key) {
            continue;
        }
        for (var i = 0; i < phonePrefix.length; i++) {
            if (phonePrefix[i].value.indexOf("Phone") >= 0
                && key.indexOf (phonePrefix[i].value) >= 0
                && !AjxUtil.isEmpty(attr[key])) {
                return attr[key];
            }
        }
    }
    return "";
}

ZmClick2CallZimlet.prototype._getTooltipBGHtml =
    function() {
        return AjxTemplate.expand("com_zimbra_click2call.templates.ZmClick2Call#Frame");
    };

// Replicating fix for bug 73264 from com_zimbra_phone

ZmClick2CallZimlet.prototype.match = function(line, startIndex) {
    //Does not match anything if unauthorized to use UC feature
    if (!appCtxt.getSettings()._hasVoiceFeature()) {
        return;
    }
    var re = this.RE;
    re.lastIndex = startIndex;
    var m = re.exec(line);
    if (!m) { return m; }

    var phone = m[0];
    // bug 73264, don't identify long digit sequence (length > 10) without separators as phone number
    if (phone.length > 10 &&
        phone[0] != "+"   &&
        !(AjxUtil.arrayContains(phone, " ")) &&
        !(AjxUtil.arrayContains(phone, ".")) &&
        !(AjxUtil.arrayContains(phone, "-"))) {
        return null;
    } else {
        m[0] = phone;
        return m;
    }
}



