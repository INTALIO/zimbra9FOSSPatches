/*
 * ***** BEGIN LICENSE BLOCK *****
 * Zimbra Collaboration Suite, Network Edition.
 * Copyright (C) 2012, 2013, 2014, 2016 Synacor, Inc.  All Rights Reserved.
 * ***** END LICENSE BLOCK *****
 * @Author Raja Rao DV
 * @Author Dongwei Feng
 *
 */

ZmClick2CallFromPhoneDlg = function(shell, parent) {
    this.zimlet = parent;
    this.toPhoneNumber = "";
    this._dialogView = new DwtComposite(appCtxt.getShell());
    this._dialogView.setSize(300, 125);
    DwtDialog.call(this, {
        parent: shell,
        className: "ZmClick2CallFromPhoneDlg",
        title: this.zimlet.getMessage("fromPhoneDlgTitle"),
        view: this._dialogView,
        standardButtons: [DwtDialog.NO_BUTTONS],
        mode: DwtBaseDialog.MODELESS
    });

    this._setWhiteBackground();
	if (!this.click2CallDlg) {
		this.click2CallDlg = new ZmClick2CallDlg(this.zimlet.getShell(), this.zimlet);
	}
    //set this to null otherwise esc will throw expn
    this._buttonDesc = {};
    this._isLoaded = false;
    this.RE = new RegExp("\\+?\\b\\d([0-9\\(\\)\\.\\s\\-]){8,20}\\d\\b");
    this.RE_EXT = new RegExp("\\d{1,8}");
};

ZmClick2CallFromPhoneDlg.prototype = new ZmDialog;
ZmClick2CallFromPhoneDlg.prototype.constructor = ZmClick2CallFromPhoneDlg;

ZmClick2CallFromPhoneDlg.prototype.CONTROLS_TEMPLATE = null;

//Set WindowInnerContainer cell's bg to white
ZmClick2CallFromPhoneDlg.prototype._setWhiteBackground = function() {
    var el = this._dialogView.getHtmlElement();
    while (el && el.className && el.className.indexOf("WindowInnerContainer") == -1) {
        el = el.parentNode;
    }
    if (el == null) {
        return;
    }
    el.style.backgroundColor = "white";
};

ZmClick2CallFromPhoneDlg.prototype.showDialog =
function() {

    if (!this._isLoaded) {
		appCtxt.setStatusMsg(ZmMsg.loading);
        this._getVoiceInfoAndShowDlg();
    } else {
        this.setToPhoneText();
        if (AjxUtil.isEmpty(this.zimlet.toPhoneNumber)) {
            this.btnCall.setEnabled(false);
        } else {
            this.btnCall.setEnabled(true);
        }
        this.popup();
    }
};

ZmClick2CallFromPhoneDlg.prototype._getVoiceInfoAndShowDlg =
function() {
    var respCallback = new AjxCallback(this, this._handleResponsePhoneInfo);
    this.zimlet.soapAPI.getUserProfile(respCallback);
};
ZmClick2CallFromPhoneDlg.prototype._handleResponsePhoneInfo = function(result) {
    if (!result.success || AjxUtil.isEmpty(result.phoneInfo)) {
        this.zimlet._popupErrorDlg(this.zimlet.getMessage("err_noPhoneNumber"));
        return;
    }

    this._createCallFromHtml(result.phoneInfo);
    this.setToPhoneText();
    this._addMinimizeAndCloseBtns();
    this.popup();
    this._isLoaded = true;
};

ZmClick2CallFromPhoneDlg.prototype._addMinimizeAndCloseBtns = function() {
    var html = ["<table><tbody><tr><td colspan='4'>",
		"<div id='", this._titleEl.id,"' style='position:relative;height:26px;'>", 
		"<div class='",this._titleEl.className,"' style='position:absolute;left:0;margin-right:44px;'>", this._titleEl.innerHTML, "</div>",
		"<div id='fromPhoneDlg_minMaxBtn' class='ImgClick2Call-minimize-icon' style='cursor:pointer;position:absolute;right:25px;top:5px;'></div>",
		"<div id='fromPhoneDlg_closeBtn' class='ImgCloseGray' style='cursor:pointer;position:absolute;right:3px;top:5px;'></div></div>",
		"</td></tr></tbody></table>"];

    // The following artifice is required due to IE's restriction on tables
    // In IE tables and table elements are readonly: so we can't use innerHTML to change them
    // The code below should work with all browsers.

    var div = document.createElement('div');
    div.innerHTML = html.join("");
    var par = this._titleEl.parentNode.parentNode;
    par.replaceChild(div.firstChild.firstChild.firstChild, this._titleEl.parentNode);

	//    this._titleEl.parentNode.innerHTML = html.join("");

	this._minMaxeDlgBtn = document.getElementById("fromPhoneDlg_minMaxBtn");
	this._minMaxeDlgBtn.onclick = AjxCallback.simpleClosure(this._handleMinMaxDlg, this);
	this._closeDlgBtn = document.getElementById("fromPhoneDlg_closeBtn");
	this._closeDlgBtn.onclick = AjxCallback.simpleClosure(this._handleCloseDlg, this);
};

ZmClick2CallFromPhoneDlg.prototype._handleMinMaxDlg = function() {
	if(this._minMaxeDlgBtn.className == "ImgClick2Call-minimize-icon") {
		this._dlgTopPosB4Minimize = (this.getHtmlElement().style.top).replace("px", "");
		this._minMaxeDlgBtn.className = "ImgClick2Call-maximize-icon ";
		this.getHtmlElement().style.top = (document.body.offsetHeight - 25) + "px";
	} else if(this._minMaxeDlgBtn.className == "ImgClick2Call-maximize-icon ") {
		this._minMaxeDlgBtn.className = "ImgClick2Call-minimize-icon";
		this.getHtmlElement().style.top = this._dlgTopPosB4Minimize + "px";
	}
};

ZmClick2CallFromPhoneDlg.prototype._handleCloseDlg = function() {
	this.popdown();
};

ZmClick2CallFromPhoneDlg.prototype._createCallFromHtml = function(phones) {
	var subs = {
		fromStr : this.zimlet.getMessage("from"),
		toStr : this.zimlet.getMessage("to")
	};
	this._dialogView.getHtmlElement().innerHTML =  AjxTemplate.expand("com_zimbra_click2call.templates.ZmClick2Call#fromPhoneDlg", subs);
    this._toPhoneTxtInput = document.getElementById("click2CallDlg_callToPHText");
    this._toPhoneTxtInput.onkeyup = AjxCallback.simpleClosure(this._handleToPhChanged, this);

    this._setFromPhoneMenu(phones);
    this._setToPhoneMenu();
    var btn = new DwtButton({
        parent: this.zimlet.getShell()
    });
    btn.setText(this.zimlet.getMessage("call"));
    //button name
    btn.setImage("Telephone");
    btn.addSelectionListener(new AjxListener(this, this._makeCall));
    document.getElementById("click2CallFromPhoneDlg_callBtn").appendChild(btn.getHtmlElement());
    this.btnCall = btn;
    if (AjxUtil.isEmpty(this.zimlet.toPhoneNumber)) {
        this.btnCall.setEnabled(false);
    }
};

ZmClick2CallFromPhoneDlg.prototype._handleToPhChanged = function () {
    if (AjxUtil.isEmpty(document.getElementById("click2CallDlg_callToPHText").value)) {
        this.btnCall.setEnabled(false);
        return;
    }
    this.btnCall.setEnabled(true);
}

ZmClick2CallFromPhoneDlg.prototype._setFromPhoneMenu = function(phones) {
    if (!phones) {
        return;
    }
    var html = [];
    var i = 0;
    html[i++] = "<select id=\"click2CallFromPhoneDlg_callFromMenu\" style='width:200px' >";
    for (var j = 0; j < phones.length; j++) {
        var phone = phones[j];
        if (!phone.deviceName) {
            continue;
        }
        html[i++] = ["<option value='", phone.deviceName, "'>", phone.phoneNumber, "</option>"].join("");

    }
    html[i++] = "</select>";
    document.getElementById("click2CallFromPhoneDlg_menuDiv").innerHTML = html.join("");
};

ZmClick2CallFromPhoneDlg.prototype._setToPhoneMenu = function() {
    //this.click2CallDlg.toPhoneNumber = document.getElementById("click2CallDlg_callToPHText").value;
    this.emailZimlet = this.zimlet.getEmailZimlet();
    var cardAttributes = this.emailZimlet && this.emailZimlet.contactCard && this.emailZimlet.contactCard.attribs;
    if (!cardAttributes) return;
    this.click2CallDlg.toPhoneNumber = this.zimlet.toPhoneNumber = cardAttributes.mobilePhone || cardAttributes.workPhone;
    /*
    var html = [];
    var i = 0;
    html[i++] = "<select id=\"click2CallFromPhoneDlg_callToMenu\" style='width:200px' >";
    for (var j = 0; j < phones.length; j++) {
        var phone = phones[j];
        html[i++] = ["<option value='", phone, "'>", phone.label, " (", phone.name, ")</option>"].join("");
    }
    html[i++] = "</select>";
    document.getElementById("click2CallFromPhoneDlg_menuDiv").innerHTML = html.join("");
    */
};

ZmClick2CallFromPhoneDlg.prototype._makeCall = function() {
    //set the value from the TO field
    this.click2CallDlg.toPhoneNumber = document.getElementById("click2CallDlg_callToPHText").value;
    this.click2CallDlg.fromDeviceName = document.getElementById("click2CallFromPhoneDlg_callFromMenu").value;
    this.click2CallDlg.fromPhoneNumber = document.getElementById("click2CallFromPhoneDlg_callFromMenu").textContent;
	if(!this.isValidPhoneNumber(this.click2CallDlg.toPhoneNumber))  {
		this._showError(AjxMessageFormat.format(this.zimlet.getMessage("notAValidPhoneNumber"), [this.click2CallDlg.toPhoneNumber]));
		return;
	}
	 this.popdown();
    this.click2CallDlg.clickToCall();
};

ZmClick2CallFromPhoneDlg.prototype.isValidPhoneNumber = function(phoneNumber) {
	return this.RE.test(phoneNumber) || this.RE_EXT.test(phoneNumber);
};

ZmClick2CallFromPhoneDlg.prototype.setToPhoneText = function() {
    document.getElementById("click2CallDlg_callToPHText").value = this.zimlet.toPhoneNumber || "";
};

ZmClick2CallFromPhoneDlg.prototype.popdown =
function() {
    ZmDialog.prototype.popdown.call(this);
};
