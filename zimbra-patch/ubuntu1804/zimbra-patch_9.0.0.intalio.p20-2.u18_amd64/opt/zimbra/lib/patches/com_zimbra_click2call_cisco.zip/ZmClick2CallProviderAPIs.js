/*
 * ***** BEGIN LICENSE BLOCK *****
 * Zimbra Collaboration Suite, Network Edition.
 * Copyright (C) 2012, 2013, 2014, 2016 Synacor, Inc.  All Rights Reserved.
 * ***** END LICENSE BLOCK *****
 * @Author Raja Rao DV
 *
 */

function ZmClick2CallProviderAPIs(zimlet, serverUrl, _username, password) {
	this.zimlet = zimlet;
	this._serverUrl = serverUrl;
	this._username = _username;
	this._password = password;

}
/*
 * Compose the SOAP message for fetching user profile
 */
ZmClick2CallProviderAPIs.prototype._getProfileXML = function() {
    var html = [];
    html.push("<?xml version=\"1.0\" encoding=\"utf-8\" ?>"
        , "<soapenv:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" "
        , " xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\""
        , " xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:urn=\"urn:WD70\">"
        , "<soapenv:Header/>"
        , "<soapenv:Body>"
        , "<urn:getProfileSoap soapenv:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\">"
        , "<in0 xsi:type=\"urn:Credential\">"
        , "<userID xsi:type=\"xsd:string\">", this._username, "</userID>"
        , "<password xsi:type=\"xsd:string\">", this._password, "</password>"
        , "</in0>"
        , "<in1 xsi:type=\"soapenc:string\" xmlns:soapenc=\"http://schemas.xmlsoap.org/soap/encoding/\">", this._username, "</in1>"
        , "</urn:getProfileSoap>"
        , "</soapenv:Body>"
        , "</soapenv:Envelope>");
    return html.join("");
};

/*
 * Compose the SOAP message for making a call
 */
ZmClick2CallProviderAPIs.prototype.getMakeCallXML = function(destination, deviceName, lineNumber, locale) {
    var html = [];
    html.push("<?xml version=\"1.0\" encoding=\"utf-8\" ?>"
        , "<soapenv:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" "
        , " xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\""
        , " xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:urn=\"urn:WD70\">"
        , "<soapenv:Header/>"
        , "<soapenv:Body>"
        , "<urn:makeCallSoap soapenv:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\">"
        , "<in0 xsi:type=\"urn:Credential\">"
        , "<userID xsi:type=\"xsd:string\">", this._username, "</userID>"
        , "<password xsi:type=\"xsd:string\">", this._password, "</password>"
        , "</in0>"
        , "<in1 xsi:type=\"soapenc:string\" xmlns:soapenc=\"http://schemas.xmlsoap.org/soap/encoding/\">"
        , destination
        , "</in1>"
        , "<in2 xsi:type=\"urn:UserProfile\">"
        , "<user xsi:type=\"xsd:string\">", this._username, "</user>"
        , "<deviceName xsi:type=\"xsd:string\">", deviceName, "</deviceName>"
        , "<lineNumber xsi:type=\"xsd:string\">", lineNumber, "</lineNumber>"
        //, "<supportEM xsi:type=\"xsd:boolean\">false</supportEM>"
        //, "<locale xsi:type=\"xsd:string\">", locale, "</locale>"
        //, "<dontAutoClose xsi:type=\"xsd:boolean\">false</dontAutoClose>"
        //, "<dontShowCallConf xsi:type=\"xsd:boolean\">true</dontShowCallConf>"
        , "</in2>"
        , "</urn:makeCallSoap>"
        , "</soapenv:Body>"
        , "</soapenv:Envelope>");

    return html.join("");
};

ZmClick2CallProviderAPIs.prototype.getClearConnectionXML = function (deviceName, lineNumber, locale) {
    var html = [];
    html.push("<?xml version=\"1.0\" encoding=\"utf-8\" ?>"
        , "<soapenv:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" "
        , " xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\""
        , " xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:urn=\"urn:WD70\">"
        , "<soapenv:Header/>"
        , "<soapenv:Body>"
        , "<urn:endCallSoap soapenv:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\">"
        , "<in0 xsi:type=\"urn:Credential\">"
        , "<userID xsi:type=\"xsd:string\">", this._username, "</userID>"
        , "<password xsi:type=\"xsd:string\">", this._password, "</password>"
        , "</in0>"
        , "<in1 xsi:type=\"urn:UserProfile\">"
        , "<user xsi:type=\"xsd:string\">", this._username, "</user>"
        , "<deviceName xsi:type=\"xsd:string\">", deviceName, "</deviceName>"
        , "<lineNumber xsi:type=\"xsd:string\">", lineNumber, "</lineNumber>"
        //, "<supportEM xsi:type=\"xsd:boolean\">false</supportEM>"
        //, "<locale xsi:type=\"xsd:string\">", locale, "</locale>"
        //, "<dontAutoClose xsi:type=\"xsd:boolean\">false</dontAutoClose>"
        //, "<dontShowCallConf xsi:type=\"xsd:boolean\">true</dontShowCallConf>"
        , "</in1>"
        , "</urn:endCallSoap>"
        , "</soapenv:Body>"
        , "</soapenv:Envelope>");

    return html.join("")
};

//userId, password
ZmClick2CallProviderAPIs.prototype.getUserProfile = function (postCallback) {
    var xml = this._getProfileXML();
    var hdrs = new Array();
    hdrs["Authorization"] = this.make_basic_auth(this._username,
        this._password);
    hdrs["content-type"] = "text/xml";
    hdrs["SOAPAction"] = "CUCM:DB ver=7.0";
    hdrs["content-length"] = xml.length;
    var feedUrl = ZmZimletBase.PROXY + AjxStringUtil.urlComponentEncode(this._serverUrl);
    var callback = new AjxCallback(this,this._getUserProfileHandler, postCallback);
    AjxRpc.invoke(xml, feedUrl, hdrs, callback, false);
};

ZmClick2CallProviderAPIs.prototype._getUserProfileHandler = function(postCallback, response) {
    var jsonObj;
    var result = {};
    if (!response.success) {
        jsonObj = this.xmlToObject(response);
        if (jsonObj && jsonObj.Body && jsonObj.Body.Fault
            && jsonObj.Body.Fault.faultstring) {
            result.success = false;
            result.error =  jsonObj.Body.Fault.faultstring.toString();
        } else { //show generic error & redial btn
            result.success = false;
            result.error =  "";
        }
    } else {
        var xmlDoc = this.xmlToObject(response, true);
        var respCode = this.getResponseCode(xmlDoc);

        if (respCode == "0") {
            var phoneInfo = this._parseDeviceInfo(xmlDoc);
            result.success = true;
            result.phoneInfo = phoneInfo;
        } else {
            result.success = false;
            var desc = this.getResponseDesc(xmlDoc)
            result.error = desc == undefined ? "" : desc;
        }
    }
    if(postCallback) {
        postCallback.run(result);
    }
}

ZmClick2CallProviderAPIs.prototype._parseDeviceInfo = function (xmlDoc) {
    var deviceInfoElement = xmlDoc.getElementsByTagName("deviceInfoList");

    if (!deviceInfoElement || deviceInfoElement.length < 1) {
        throw "Empty device number"
    }
    var deviceInfoList = deviceInfoElement[0].childNodes;
    var phoneInfo = [];
    for (var i = 0; i < deviceInfoList.length; i++) {
        var device = deviceInfoList[i];
        var id = device.getAttribute("href");
        if (!id) {
            continue;
        }
        var deviceElement = this._getMultiRefElementById(xmlDoc, id.substring(1));
        if (!deviceElement) {
            continue;
        }

        var deviceName;
        if (AjxEnv.isIE) {
            deviceName = AjxStringUtil.trim(deviceElement.firstChild.text);
        } else {
            deviceName = AjxStringUtil.trim(deviceElement.firstChild.textContent);
        }

        var phoneList = deviceElement.lastChild.childNodes;
        for (var j = 0; j < phoneList.length; j++) {
            var phoneText;
            if (AjxEnv.isIE) {
                phoneText = phoneList[j].text;
            } else {
                phoneText = phoneList[j].textContent;
            }
            if (AjxUtil.isEmpty(phoneText)){
                continue;
            }
            var index = phoneText.indexOf(";");
            if (index < 0) {
                continue;
            }
            var phoneNumber = AjxStringUtil.trim(phoneText.substring(0, index - 1));
            phoneInfo.push({deviceName: deviceName, phoneNumber: phoneNumber});
        }
    }
    return phoneInfo;
}

ZmClick2CallProviderAPIs.prototype._getMultiRefElementById = function (xmlDoc, id) {
    if (!xmlDoc || !id) {
        return null;
    }

    var refs = xmlDoc.getElementsByTagName("multiRef");
    if (!refs)
        return null;

    for (var i = 0; i < refs.length; i++) {
        var refId = refs[i].getAttribute("id");
        if (refId == id) {
            return refs[i];
        }
    }
    return null;
}

//userId, password, destination, deviceName, lineNumber, locale
ZmClick2CallProviderAPIs.prototype.doClick2Call = function (fromDeviceName, fromPhoneNumber, toPhoneNumber, postCallback) {
    var xml = this.getMakeCallXML(toPhoneNumber, fromDeviceName, fromPhoneNumber, null);
    var hdrs = new Array();
    hdrs["Authorization"] = this.make_basic_auth(this._username,
        this._password);
    hdrs["content-type"] = "text/xml";
    hdrs["SOAPAction"] = "CUCM:DB ver=7.0";
    hdrs["content-length"] = xml.length;
    var feedUrl = ZmZimletBase.PROXY + AjxStringUtil.urlComponentEncode(this._serverUrl);
    var callback = new AjxCallback(this,this._call2CallHandler, postCallback);
    AjxRpc.invoke(xml, feedUrl, hdrs, callback, false);
};

ZmClick2CallProviderAPIs.prototype._call2CallHandler = function(postCallback, response) {
    var jsonObj;
    var result = {};
    if (!response.success) {
        jsonObj = this.xmlToObject(response);
        result.success = false;
        if (jsonObj && jsonObj.Body && jsonObj.Body.Fault
            && jsonObj.Body.Fault.faultstring) {
            result.error =  jsonObj.Body.Fault.faultstring.toString();
        } else { //show generic error & redial btn
            result.error =  "";
        }
    } else {
        var xmlDoc = this.xmlToObject(response, true);
        var respCode = this.getResponseCode(xmlDoc);
        if (respCode == "0") {
            result.success = true;
        } else {
            result.success = false;
            var desc = this.getResponseDesc(xmlDoc)
            result.error = desc == undefined ? "" : desc;
        }
    }
    if(postCallback) {
        postCallback.run(result);
    }
};

ZmClick2CallProviderAPIs.prototype.doHangUp = function (fromDeviceName, fromPhoneNumber, postCallback) {
    var xml = this.getClearConnectionXML(fromDeviceName, fromPhoneNumber, null);
    var hdrs = new Array();
    hdrs["Authorization"] = this.make_basic_auth(this._username,
        this._password);
    hdrs["content-type"] = "text/xml";
    hdrs["SOAPAction"] = "CUCM:DB ver=7.0";
    hdrs["content-length"] = xml.length;
    var feedUrl = ZmZimletBase.PROXY + AjxStringUtil.urlComponentEncode(this._serverUrl);
    AjxRpc.invoke(xml, feedUrl, hdrs, new AjxCallback(this,
        this._hangupHandler, postCallback), false);
};

ZmClick2CallProviderAPIs.prototype._hangupHandler = function(postCallback, response) {
	var result = {};
	/**  API DOESNT WORK PROPERLY - Mitel is investigating
	var jsonObj = this.xmlToObject(response);
	var result = {};
	if (!response.success) {
		if (jsonObj && jsonObj.Body && jsonObj.Body.Fault
				&& jsonObj.Body.Fault.faultstring) {
			result.success = false;
			result.error =  jsonObj.Body.Fault.faultstring.toString();
		} else { //show generic error & redial btn
			result.success = false;
			result.error =  "";
		}
	} else {
		jsonObj = this.xmlToObject(response);
		if (jsonObj.Body) {
			result.success = true;
		}
	}*/
	result = {success:true};
	if(postCallback) {
		postCallback.run(result);
	}
};

ZmClick2CallProviderAPIs.prototype.make_basic_auth = function(user, password) {
	var tok = user + ':' + password;
	var hash = Base64.encode(tok);
	return "Basic " + hash;
};

ZmClick2CallProviderAPIs.prototype.xmlToObject = function(result, dontConvertToJSObj) {
	if(!result.success) {
		this.zimlet.displayErrorMessage(this.zimlet.getMessage("coulNotConnect"), result.text, this.zimlet.getMessage("providerError"));
		return;
	}
	if (dontConvertToJSObj) {
		var xd = new AjxXmlDoc.createFromDom(result.xml);
	} else {
		var xd = new AjxXmlDoc.createFromDom(result.xml)
				.toJSObject(true, false);
	}
	return xd;
};

ZmClick2CallProviderAPIs.prototype.getResponseCode = function (ajxXmlDoc) {
    if (!ajxXmlDoc) {
        return undefined;
    }

    var rspCodeEle = ajxXmlDoc.getElementsByTagName("responseCode");
    if (!rspCodeEle || rspCodeEle.length == 0) {
        return undefined;
    }

    var eleId = rspCodeEle[0].getAttribute("href");
    if (!eleId) {
        //No reference ID, try to re
        if (AjxEnv.isIE) {
            return rspCodeEle[0].text;
        }
        return rspCodeEle[0].textContent;
    }

    var refParts = ajxXmlDoc.getElementsByTagName("multiRef");
    if (!refParts || refParts.length == 0) {
        return undefined;
    }
	var responseCode = false;
    for (var i = 0; i < refParts.length && responseCode === false; i++) {
        if (("#" + refParts[i].getAttribute("id")) == eleId) {
            if (AjxEnv.isIE) {
                responseCode = refParts[i].text;
            } else {
                responseCode = refParts[i].textContent;
            }
            break;
        }
    }
	
	//take one more look at it, just to be sure
	if (responseCode) {
		return responseCode;
	}
	else {
		//do we have success in the description?
		var descriptionNodes = ajxXmlDoc.getElementsByTagName("description");
		var responseDescriptionNodes = ajxXmlDoc.getElementsByTagName("responseDescription");
		if (!descriptionNodes || descriptionNodes.length == 0) {
			if (!responseDescriptionNodes || responseDescriptionNodes.length == 0) {
				return undefined;
			}
			else {
				descriptionNodes = responseDescriptionNodes;
			}
		}
		for (var i=0; i<descriptionNodes.length; i++) {
			responseCode = AjxEnv.isIE ? descriptionNodes[i].text : descriptionNodes[i].textContent;
			if (responseCode && responseCode.toLowerCase() == "success") {
				return "0"; //not very clear but that's what we are expecting
			}
		}
	}
    return undefined;
}

ZmClick2CallProviderAPIs.prototype.getResponseDesc = function (ajxXmlDoc) {
    var rspCodeEle = ajxXmlDoc.getElementsByTagName("responseDescription");
    if (!rspCodeEle || rspCodeEle.length == 0) {
        return undefined;
    }
    //No reference ID, try to re
    if (AjxEnv.isIE) {
        return rspCodeEle[0].text;
    }
    return rspCodeEle[0].textContent;
}