/*
 * ***** BEGIN LICENSE BLOCK *****
 * Zimbra Collaboration Suite, Network Edition.
 * Copyright (C) 2012, 2014, 2016 Synacor, Inc.  All Rights Reserved.
 * ***** END LICENSE BLOCK *****
 */
function ZmClick2CallPresenceAPIs(zimlet, _username, serverUrl, _appSessionId) {
    this.zimlet = zimlet;
    this._serverUrl = serverUrl;
    this._username = _username;
    this._appSessionId = _appSessionId;

}

ZmClick2CallPresenceAPIs.prototype.login = function (presenceLoginCallback, force) {
	if (!this._appSessionId) return; //can't login, don't wait CPU time trying
	var loginCallback = new AjxCallback(this, this._loginContinuation);
	if (!force) {
		this._getSessionIdFromMetadata(loginCallback, presenceLoginCallback);
	}
	else {
		loginCallback.run(presenceLoginCallback);
	}
};

ZmClick2CallPresenceAPIs.prototype._loginContinuation = 
function(presenceLoginCallback) {
	var url = [this._serverUrl, "/", this._username, "/session"].join("");
	var proxyUrl = [ZmZimletBase.PROXY, AjxStringUtil.urlComponentEncode(url)].join("");
	var requestHeaders = {};
	requestHeaders["Presence-Session-Key"] = this._appSessionId;
	var cb = new AjxCallback(this, this._loginResponseHandler, [presenceLoginCallback]);
	var response = AjxRpc.invoke(null, proxyUrl, requestHeaders, cb, AjxRpcRequest.HTTP_PUT);	
};

ZmClick2CallPresenceAPIs.prototype._getSessionIdFromMetadata = 
function(loginCallback, presenceLoginCallback) {
	var metadata = new ZmMetaData(appCtxt.getActiveAccount());
	metadata.get("ciscoPresenceZimlet", null, new AjxCallback(this, this._handleSessionIdMetadata, [loginCallback, presenceLoginCallback]));
};

ZmClick2CallPresenceAPIs.prototype._handleSessionIdMetadata = 
function(loginCallback, presenceLoginCallback, result) {
	var response = result.getResponse();
	if(response && response.BatchResponse && response.BatchResponse.GetMailboxMetadataResponse) {
		response = response.BatchResponse.GetMailboxMetadataResponse[0];
	} else {
		this._sessionId = null;
		if (loginCallback) {
			loginCallback.run();
		}
	}
	try {
		if (response.meta && response.meta[0] && response.meta[0]._attrs) {
			this._sessionId = response.meta[0]._attrs["cisco_enduser_sessionid"];
		}
		else {
			this._sessionId = null;
			if (loginCallback) {
				loginCallback.run(presenceLoginCallback);
			}
			return;
		}
		if (presenceLoginCallback) {
			presenceLoginCallback.run();
		} 
	} catch(ex) {
		this._sessionId = null;
		if (loginCallback) {
			loginCallback.run(presenceLoginCallback);
		}
	}
};

/**
 * Parse response to retrieve the session id.
 *
 * Possible error codes:
 * <ul>
 *     <li>100: Session key not present in request
 *     <li>101: Invalid session key
 *     <li>114:  Failed to login user
 *     <li>140: You must be an end user to perform this task
 *     <li>160: User is already logged in
 *     <li>210: Max cpu utilization reached
 * </ul>
 */
ZmClick2CallPresenceAPIs.prototype._loginResponseHandler =
function(presenceLoginCallback, results) {
    /*
     * TODO: handle login request errors so we try again.
     */
    var result = {};
    if (results && results.success) {
		var xml = results.text.replace(/<!DOCTYPE.*>/,'');
		result = AjxXmlDoc.createFromXml(xml).toJSObject(true, false);
        if (result && result.sessionKey) {
            this._sessionId = result.sessionKey.__msh_content;
			//store in mailbox metadata
			var metadata = new ZmMetaData(appCtxt.getActiveAccount());
			var keyValArry = [];
			keyValArry["cisco_enduser_sessionid"] = this._sessionId;
			metadata.set("ciscoPresenceZimlet", keyValArry);
        }
    } else {
        var errorCode = this._parseCiscoErrorCodes(results.text);
        if (errorCode) {
            result.errorCode = errorCode;
        } else {
            result.errorCode = "unknown";
        }
        //alert("errorCode = " + errorCode);
        /*if (errorCode == 101) {
            //need to get application user session key from server
        }
        else if (errorCode == 160) {
            //need to run forced login -- shouldn't get here
        }
        else if (errorCode == 210) {
            //set a timeout interval and try again
        }*/
        //TODO: AjxDebug the error
    }
    if (presenceLoginCallback) {
        presenceLoginCallback.run(result);
    }
};

ZmClick2CallPresenceAPIs.prototype._parseCiscoErrorCodes =
function(xml) {
    /*
     <description xmlns="urn:cisco:cup:presence:soap">
     <code>101</code>
     <message>Invalid session key</message>
     <fix>Ensure the user is logged in or try logging in the user again</fix>
     </description>
     */
    if (xml) {
		xml = xml.replace(/<!DOCTYPE.*>/,'');
		var result = AjxXmlDoc.createFromXml(xml);
        var doc = result && result.getDoc();
		var code = doc.getElementsByTagName("code");
        if (code && code.length) {
            return AjxEnv.isIE? code[0].text : code[0].textContent;
        }
    }
};

ZmClick2CallPresenceAPIs.prototype.getPresence =
function(contact, getPresenceCallback) {
	if (!this._sessionId) {
		DBG.println(AjxDebug.DBG1, "ZmClick2CallPresenceAPIs: no session id, trying to login");
		return;
	} 
	this.getRichPresence(contact, getPresenceCallback);
};

ZmClick2CallPresenceAPIs.prototype.getBasicPresence =
function(contact, getPresenceCallback) {
	/*
	 GET /presence-service/users/{username}/presence/{type}/contacts/{contactsList}
	 HTTP/1.1
	 Presence-Session-Key: {end-user-session-key}
	 */
	//debugger;
	if (!this._sessionId) return; //can't login don't waste CPU trying. this should really be a retry.
	var url = [this._serverUrl, "/", this._username, "/presence/basic/contacts/", contact].join("");
	var proxyUrl = [ZmZimletBase.PROXY, AjxStringUtil.urlComponentEncode(url)].join("");
	var requestHeaders = {};
	requestHeaders["Presence-Session-Key"] = this._sessionId;
	var cb  = new AjxCallback(this, this._getPresenceResponse, [getPresenceCallback, "basic"]);
	var response = AjxRpc.invoke(null, proxyUrl, requestHeaders, cb, AjxRpcRequest.HTTP_GET);
};

ZmClick2CallPresenceAPIs.prototype.getRichPresence =
function(contact, getPresenceCallback) {
    /*
     GET /presence-service/users/{username}/presence/{type}/contacts/{contactsList}
     HTTP/1.1
     Presence-Session-Key: {end-user-session-key}
     */
	if (!this._sessionId) return; //can't login don't waste CPU trying. this should really be a retry.
    var url = [this._serverUrl, "/", this._username, "/presence/rich/contacts/", contact].join("");
    var proxyUrl = [ZmZimletBase.PROXY, AjxStringUtil.urlComponentEncode(url)].join("");
    var requestHeaders = {};
    requestHeaders["Presence-Session-Key"] = this._sessionId;
    var cb  = new AjxCallback(this, this._getPresenceResponse, [getPresenceCallback, "rich"]);
    var response = AjxRpc.invoke(null, proxyUrl, requestHeaders, cb, AjxRpcRequest.HTTP_GET);
};

ZmClick2CallPresenceAPIs.prototype._getPresenceResponse =
function(getPresenceCallback, requestType, results) {
    /*
     Available
     <person id ="p1" > <activities>
     <available/> </activities>
     </person>

     Busy
     <person id="p2" > <activities>
     <busy/> </activities>
     </person>

     Do Not Disturb
     <person id="p3" > <activities>
     <dnd/> </activities>
     </person>

     Away
     <person id="p4" > <activities>
     <away/> </activities>
     </person>

     On Vacation
     <person id="p5" > <activities> <vacation/>
     </activities> </person>

     Unavailable
     <person id="p6" > <activities>
     <unavailable/> </activities>
     </person>

     Unknown
     <person id="p7" > <activities>
     <unknown/> </activities>
     </person>

     here is the response text I got while I was *not* on Phone and "Do Not Disturb" on IM
     <activities>
     <dnd/>
     <phone-status>
     available
     </phone-status>
     <im-status>available</im-status>
     </activities>


     and this one is while I was on phone and IM Status was "Do Not Disturb"
     <activities>

     <derived>
     <busy>
     <on-the-phone/>
     </busy>
     </derived>

     <dnd/> <on-the-phone/>

     <im-status>available</im-status>

     </activities>


     and this is with on phone but IM status "Available"
     <activities>
     <busy/>
     <on-the-phone/>
     <im-status>available</im-status></activities>
     */

    var result = {};
    if (results && results.success) {
		var xml = results.text.replace(/<!DOCTYPE.*>/,'');
		result = AjxXmlDoc.createFromXml(xml);
		var person = result.getElementsByTagName("person");
		if (person && person.length > 0) {			
			var status_array = ["dnd", "vacation", "on-the-phone", "busy", "unavailable", "away", "available", "unknown"];
			for (var i=0; i < status_array.length; i++) {
				var s =  status_array[i];
				var nl = person[0].getElementsByTagName(s);
				if (nl && nl.length > 0) {
					result.presenceStatus = s;
					break;
				}
			}
			var notes = person[0].getElementsByTagName("note");
			if (notes && notes.length > 0) {
				result.notes = AjxStringUtil.htmlEncode(AjxEnv.isIE? notes[0].text : notes[0].textContent);
			}
			else {
				result.notes = "";
			}
		}
	    else {
		  result.presenceStatus = "unknown";
		}
    }
    else {
        var errorCode = this._parseCiscoErrorCodes(results.text);
        if (errorCode) {
            result.errorCode = errorCode;
        } else {
            result.errorCode = "unknown";
        }
		
        if (errorCode == 101) {
           //mailbox metadata value for sessionid is probably stale.  try to get it again
		   this._sessionId = null; //clear the session id
		   this.login(null, true);
		   return;
        }
		/*
        else if (errorCode == 160) {
            //need to run forced login -- shouldn't get here
        }
        else if (errorCode == 210) {
            //set a timeout interval and try again
        }*/
        //TODO: AjxDebug the error
    }

    if (getPresenceCallback) {
        getPresenceCallback.run(result);
    }
};